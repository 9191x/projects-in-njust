package edu.njust.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {
	public static SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
	public static Date getDate(String a){
		Date d = null;
		try {
			d = sdf.parse(a);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return d;
		
	}

}
