package edu.njust.entity;

import java.util.Date;

public class Student {
      private int account;
      private String name;
      private String pwd;
      private Date brithday;
      private String email;
      private String phone;
      private int accstatus;
  	  private int classtime;
  	  private int parentsnum;
      public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
    
	public Student(int account, String pwd) {
		super();
		this.account = account;
		this.pwd = pwd;
	}

	public Student(String name, String pwd, Date brithday, String email,
			String phone) {
		super();
		this.name = name;
		this.pwd = pwd;
		this.brithday = brithday;
		this.email = email;
		this.phone = phone;
	}

	public Student(int account, String name, String pwd, Date brithday,
			String email, String phone, int acc_status, int classtime,
			int parentsnum) {
		super();
		this.account = account;
		this.name = name;
		this.pwd = pwd;
		this.brithday = brithday;
		this.email = email;
		this.phone = phone;
		this.accstatus = acc_status;
		this.classtime = classtime;
		this.parentsnum = parentsnum;
	}
	@Override
	public String toString() {
		return "Student [account=" + account + ", name=" + name + ", pwd="
				+ pwd + ", brithday=" + brithday + ", email=" + email
				+ ", phone=" + phone + ", acc_status=" + accstatus
				+ ", classtime=" + classtime + ", parentsnum=" + parentsnum
				+ "]";
	}
	public int getAccount() {
		return account;
	}
	public void setAccount(int account) {
		this.account = account;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public Date getBrithday() {
		return brithday;
	}
	public void setBrithday(Date brithday) {
		this.brithday = brithday;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public int getAcc_status() {
		return accstatus;
	}
	public void setAcc_status(int acc_status) {
		this.accstatus = acc_status;
	}
	public int getClasstime() {
		return classtime;
	}
	public void setClasstime(int classtime) {
		this.classtime = classtime;
	}
	public int getParentsnum() {
		return parentsnum;
	}
	public void setParentsnum(int parentsnum) {
		this.parentsnum = parentsnum;
	}

	public Student(String name, String pwd, int account) {
		super();
		this.name = name;
		this.pwd = pwd;
		this.account=account;
	}

	

    
}
