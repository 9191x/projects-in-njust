package edu.njust.entity;

public class Informer {
	    private Integer account;
	    private  String name;
	    private String pwd;
	    private String phone;
		public Informer() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		public Informer(Integer account, String pwd) {
			super();
			this.account = account;
			this.pwd = pwd;
		}

		public Informer(Integer account, String name, String pwd, String phone) {
			super();
			this.account = account;
			this.name = name;
			this.pwd = pwd;
			this.phone = phone;
		}
		public Integer getAccount() {
			return account;
		}
		public void setAccount(Integer account) {
			this.account = account;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getPwd() {
			return pwd;
		}
		public void setPwd(String pwd) {
			this.pwd = pwd;
		}
		public String getPhone() {
			return phone;
		}
		public void setPhone(String phone) {
			this.phone = phone;
		}
		public Informer(String name, String pwd, String phone) {
			super();
			this.name = name;
			this.pwd = pwd;
			this.phone = phone;
		}
	    
}
