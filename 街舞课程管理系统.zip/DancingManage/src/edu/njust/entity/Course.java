package edu.njust.entity;

public class Course {
	
	    private Integer id;
	    private  String type;
	    private Integer studentnum;
	    private String teachername;
	    private Integer teacheracc;
	    private Integer courseifdel;
	    private Integer coursestatus;
		public Course() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		@Override
		public String toString() {
			return "Course [id=" + id + ", type=" + type + ", studentnum="
					+ studentnum + ", teachername=" + teachername
					+ ", teacheracc=" + teacheracc + ", courseifdel="
					+ courseifdel + ", coursestatus=" + coursestatus + "]";
		}

		public Course(Integer id, String type, String teachername,
				Integer teacheracc) {
			super();
			this.id = id;
			this.type = type;
			this.teachername = teachername;
			this.teacheracc = teacheracc;
		}

		public Course(Integer id, String type, Integer studentnum,
				String teachername, Integer teacheracc, Integer courseifdel,
				Integer coursestatus) {
			super();
			this.id = id;
			this.type = type;
			this.studentnum = studentnum;
			this.teachername = teachername;
			this.teacheracc = teacheracc;
			this.courseifdel = courseifdel;
			this.coursestatus = coursestatus;
		}
		public Integer getId() {
			return id;
		}
		public void setId(Integer id) {
			this.id = id;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public Integer getStudentnum() {
			return studentnum;
		}
		public void setStudentnum(Integer studentnum) {
			this.studentnum = studentnum;
		}
		public String getTeachername() {
			return teachername;
		}
		public void setTeachername(String teachername) {
			this.teachername = teachername;
		}
		public Integer getTeacheracc() {
			return teacheracc;
		}
		public void setTeacheracc(Integer teacheracc) {
			this.teacheracc = teacheracc;
		}
		public Integer getCourseifdel() {
			return courseifdel;
		}
		public void setCourseifdel(Integer courseifdel) {
			this.courseifdel = courseifdel;
		}
		public Integer getCoursestatus() {
			return coursestatus;
		}
		public void setCoursestatus(Integer coursestatus) {
			this.coursestatus = coursestatus;
		}
		
		
	    
}