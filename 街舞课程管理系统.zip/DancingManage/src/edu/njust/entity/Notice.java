package edu.njust.entity;

public class Notice {
      Integer id;
      Integer account;
      String noticess;
	public Notice() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Notice(Integer account, String noticess) {
		super();
		this.account = account;
		this.noticess = noticess;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getAccount() {
		return account;
	}
	public void setAccount(Integer account) {
		this.account = account;
	}
	public String getNoticess() {
		return noticess;
	}
	public void setNoticess(String noticess) {
		this.noticess = noticess;
	}
      
}
