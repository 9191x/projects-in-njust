package edu.njust.entity;

public class CourseMsg {
	private Integer courseid;
	private Integer account;
	public CourseMsg() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CourseMsg(Integer id, Integer account) {
		super();
		this.courseid = id;
		this.account = account;
	}
	public Integer getCourseid() {
		return courseid;
	}
	public void setCourseid(Integer courseid) {
		this.courseid = courseid;
	}
	public Integer getAccount() {
		return account;
	}
	public void setAccount(Integer account) {
		this.account = account;
	}
	

}