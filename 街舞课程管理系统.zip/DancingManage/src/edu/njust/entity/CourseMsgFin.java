package edu.njust.entity;


public class CourseMsgFin {
	    private  String type;
	    private Integer studentnum;
	    private String teachername;
	    private Integer account;
	    private  String  time  ;
		public CourseMsgFin() {
			super();
			// TODO Auto-generated constructor stub
		}
		public CourseMsgFin(String type, Integer studentnum,
				String teachername, Integer account, String time) {
			super();
			this.type = type;
			this.studentnum = studentnum;
			this.teachername = teachername;
			this.account = account;
			this.time = time;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public Integer getStudentnum() {
			return studentnum;
		}
		public void setStudentnum(Integer studentnum) {
			this.studentnum = studentnum;
		}
		public String getTeachername() {
			return teachername;
		}
		public void setTeachername(String teachername) {
			this.teachername = teachername;
		}
		public Integer getAccount() {
			return account;
		}
		public void setAccount(Integer account) {
			this.account = account;
		}
		public String getTimes() {
			return time;
		}
		public void setTimes(String time) {
			this.time = time;
		}
	    
		
}
