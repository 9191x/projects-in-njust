package edu.njust.entity;

public class Administrator {
	 private Integer account;
	 private String pwd;
	public Administrator(Integer account, String pwd) {
		super();
		this.account = account;
		this.pwd = pwd;
	}
	public Administrator() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getAccount() {
		return account;
	}
	public void setAccount(Integer account) {
		this.account = account;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	 
}
