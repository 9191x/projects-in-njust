package edu.njust.entity;

public class Teacher {
    private Integer account;
    private  String name;
    private String pwd;
    private String phone;
    private Integer teachstunum;
    private Integer teachcousenum;
    private Integer paynum;
	public Teacher() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Teacher(Integer account, String name, String pwd, String phone,
			Integer teachstunum, Integer teachcousenum, Integer paynum) {
		super();
		this.account = account;
		this.name = name;
		this.pwd = pwd;
		this.phone = phone;
		this.teachstunum = teachstunum;
		this.teachcousenum = teachcousenum;
		this.paynum = paynum;
	}
	
	public Teacher(Integer account, String pwd) {
		super();
		this.account = account;
		this.pwd = pwd;
	}
	public Teacher(String name, String pwd, String phone) {
		super();
		this.name = name;
		this.pwd = pwd;
		this.phone = phone;
	}
	public Integer getAccount() {
		return account;
	}
	public void setAccount(Integer account) {
		this.account = account;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public Integer getTeachstunum() {
		return teachstunum;
	}
	public void setTeachstunum(Integer teachstunum) {
		this.teachstunum = teachstunum;
	}
	public Integer getTeachcousenum() {
		return teachcousenum;
	}
	public void setTeachcousenum(Integer teachcousenum) {
		this.teachcousenum = teachcousenum;
	}
	public Integer getPaynum() {
		return paynum;
	}
	public void setPaynum(Integer parnum) {
		this.paynum = parnum;
	}
	@Override
	public String toString() {
		return "Teacher [account=" + account + ", name=" + name + ", pwd="
				+ pwd + ", phone=" + phone + ", teachstunum=" + teachstunum
				+ ", teachcousenum=" + teachcousenum + ", paynum=" + paynum
				+ "]";
	}
    
                

}
