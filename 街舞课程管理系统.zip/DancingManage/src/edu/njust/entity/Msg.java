package edu.njust.entity;

public class Msg {

	private Integer id;
	private String name;
	private String context;
	//private String reply;
	
	public Msg() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Msg(String name, String context) {
		super();
		this.name = name;
		this.context = context;
	}
	
	public Msg(Integer id, String name, String context) {
		super();
		this.id = id;
		this.name = name;
		this.context = context;
	}
	/*public Msg(Integer id, String name, String context, String reply) {
		super();
		this.id = id;
		this.name = name;
		this.context = context;
		this.reply = reply;
	}*/
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContext() {
		return context;
	}
	public void setContext(String context) {
		this.context = context;
	}
	/*public String getReply() {
		return reply;
	}
	public void setReply(String reply) {
		this.reply = reply;
	}
	*/
}
