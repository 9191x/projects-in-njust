package edu.njust.entity;

public class Parent {
	private int account;
	private String name;
	private String pwd;
	private int chindaccount;
	private String chindname;
	private String email;
	private String phone;
	public Parent(int account, String pwd) {
		super();
		this.account = account;
		this.pwd = pwd;
	}
	public Parent(String name, String pwd, int chind_account,
			String chind_name, String email, String phone) {
		super();
		this.name = name;
		this.pwd = pwd;
		this.chindaccount = chind_account;
		this.chindname = chind_name;
		this.email = email;
		this.phone = phone;
	}

	public Parent(int account, String name, String pwd, int chind_account,
			String chind_name, String email, String phone) {
		super();
		this.account = account;
		this.name = name;
		this.pwd = pwd;
		this.chindaccount = chindaccount;
		this.chindname = chindname;
		this.email = email;
		this.phone = phone;
	}
	

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public Parent() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	@Override
	public String toString() {
		return "Parent [account=" + account + ", name=" + name + ", pwd=" + pwd
				+ ", chind_account=" + chindaccount + ", chind_name="
				+ chindname + ", email=" + email + ", phone=" + phone + "]";
	}

	public int getAccount() {
		return account;
	}
	public void setAccount(int account) {
		this.account = account;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getChind_account() {
		return chindaccount;
	}
	public void setChind_account(int chind_account) {
		this.chindaccount = chind_account;
	}
	public String getChind_name() {
		return chindname;
	}
	public void setChind_name(String chind_name) {
		this.chindname = chind_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	
}
