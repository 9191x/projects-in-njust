package edu.njust.service;

import java.util.List;

import edu.njust.dao.CourseMsgFinMapper;
import edu.njust.dao.CourseMsgMapper;
import edu.njust.entity.CourseMsg;
import edu.njust.entity.CourseMsgFin;
import edu.njust.mybatis.CourseMsgDaoImpl;
import edu.njust.mybatis.CourseMsgFinDaoImpl;

public class CourseMsgService {
	CourseMsgMapper a1=new CourseMsgDaoImpl();
	CourseMsgFinMapper b1=new CourseMsgFinDaoImpl();
	 public void addCourseMsg1(CourseMsg cm){
		 a1.addCourseMsg1(cm);
	 };
	 public void addCourseMsg2(CourseMsgFin cm){
		 b1.addCourseMsg2(cm);
	 };
	 public void delCourseMsg(CourseMsg cm){
		 a1.delCourseMsg(cm);
	 };
	 public void delCourseMsg1byCourse(Integer id){
		 a1.delCourseMsg1byCourse(id);
	 };
	 public List<CourseMsg> getCourseMsgs1(Integer account){
		 return a1.getCourseMsgs1(account);
				 
	 };
	 public List<CourseMsg> getCourseMsgs1Byid(Integer aid){
		 return a1.getCourseMsgs1Byid(aid);
				 
	 };
	 public List<CourseMsgFin> getCourseMsgs2(Integer account){
		 return b1.getCourseMsgs2(account);
				 
	 };
}
