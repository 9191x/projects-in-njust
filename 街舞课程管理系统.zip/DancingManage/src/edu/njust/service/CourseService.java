package edu.njust.service;

import java.util.List;

import edu.njust.dao.CourseMapper;
import edu.njust.entity.Course;
import edu.njust.mybatis.CourseDaoImpl;

public class CourseService {
	
	private  CourseMapper a1=new CourseDaoImpl();
	public void addCourse(Course c1){
	    a1.addCourse(c1);  
	};
    public void delCourse(Integer id){
    	a1.delCourse(id);
    };
    public Course getCourse(Integer id){
    	return a1.getCourse(id);
    };
    public List<Course> getCourses(){
    	return a1.getCourses();
    };
    public Integer getStatus(Integer id){
    	return a1.getStatus(id);
    };
    public void changeStatus(Integer id){
    	a1.changeStatus(id);}
    public void changeIfdel(Integer id){
        	a1.changeIfdel(id);
    }
    public void returnIfdel(Integer id){
    	a1.returnIfdel(id);
     }
    public void bookCourse(Integer id){
    	a1.bookCourse(id);
    };
    public void resetStuNum(Integer id){
    	a1.resetStuNum(id);
    };
    public void delbookCourse(Integer id){
    	a1.delbookCourse(id);
    };
}
