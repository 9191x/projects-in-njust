package edu.njust.service;


import java.util.List;

import edu.njust.dao.MsgMapper;
import edu.njust.entity.Msg;
import edu.njust.mybatis.MsgDaoImpl;

public class MsgService {

	
private MsgMapper a =new MsgDaoImpl();
	
	public List<Msg> getMsgs() {
		
		return a.getMsgs();

	}
	//public Student getStudent(int account){
	//	return a.getStudent(account);
	//}

    public void addMsg(Msg msg){
    	a.addMsg(msg);
    }
    
    public void delMsg(int id){
    	a.delMsg(id);
    }

}
