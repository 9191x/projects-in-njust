package edu.njust.service;

import java.util.List;

import org.junit.Test;

import edu.njust.dao.ParentMapper;
import edu.njust.entity.Parent;
import edu.njust.mybatis.ParentDaoImpl;
public class ParentService {
	private ParentMapper a =new ParentDaoImpl();
	
	public List<Parent> getParents() {
		
		return a.getParents();

	}
    public void addParent(Parent par){
    	a.addParent(par);
    }
    public boolean comParent(Parent par){
    	return a.comParent(par);
    }
    public void delParent(Integer account){
    	a.delParent(account);
    }
    public Parent getParentbyTel(String tel){
    	return a.getParentbyTel(tel);
    }
   
}
