package edu.njust.service;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import edu.njust.dao.StudentMapper;
import edu.njust.entity.Student;
import edu.njust.mybatis.StudentDaoImpl;

public class StudentService {
	private StudentMapper a =new StudentDaoImpl();
	
	public List<Student> getStudents() {
		
		return a.getStudents();

	}
	public Student getStudent(int account){
		return a.getStudent(account);
	}
	public void addClasstime1(int account){
		a.addClasstime1(account);
	}
	public void addClasstime2(int account){
		a.addClasstime2(account);
	}
	public void delStudent(int account){
		a.delStudent(account);
	}
    public void addStudent(Student stu){
    	a.addStudent(stu);
    }
    public boolean comStudent(Student stu){
    	return a.comStudent(stu);
    }
    public void changeStatus9(Integer account){
    	a.changeStatus9(account);
    }
    public void changeStatus1(Integer account){
    	a.changeStatus1(account);
    }
    public void changeStatus2(Integer account){
    	a.changeStatus2(account);
    }
    public void haveClass(Integer account){
    	a.haveClass(account);
    };
    public Student getStudentbyTel(String phone){
    	return a.getStudentbyTel(phone);
    };
    public Integer getStudentStatus(Integer account){
    	return a.getStudentStatus(account);
    };
    public Integer getParentNum(Integer account){
    	return a.getParentNum(account);
    };
    public void newParent(Integer account){
    	a.newParent(account);
    }
    public boolean addParent(Student bbb){
    	Student d = a.addParent(bbb);
    	if(d==null)
    	    return false;
    	else
    		return true;
    }
}


