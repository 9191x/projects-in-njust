package edu.njust.service;


import java.util.List;

import edu.njust.dao.NoticeMapper;
import edu.njust.entity.Notice;
import edu.njust.mybatis.NoticeDaoImpl;

public class NoticeService {
	private NoticeMapper a =new NoticeDaoImpl();
	public void addNotice(Notice notice){
		a.addNotice(notice);
	};
    //public void updateMsg(Msg msg);
    public void delNotice(Integer id){
    	a.delNotice(id);
    };
    //public Student getStudent(int account);
    //public boolean  comStudent(Student stu);
    public List<Notice> getNotices(Integer account){
    	return a.getNotices(account);
    };
}
