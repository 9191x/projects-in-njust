package edu.njust.service;

import java.util.List;

import edu.njust.dao.InformerMapper;
import edu.njust.entity.Informer;
import edu.njust.entity.Parent;
import edu.njust.mybatis.InformerDaoImpl;
import edu.njust.mybatis.ParentDaoImpl;

public class InformerService {
private InformerMapper a =new InformerDaoImpl();
	
	public List<Informer> getInformers() {
		
		return a.getInformers();

	}
    public void addInformer(Informer inf){
    	a.addInformer(inf);
    }
    public boolean comInformer(Informer inf){
    	return a.comInformer(inf);
    }
    public void delInformer(Integer account){
    	a.delInformer(account);
    }
}
