package edu.njust.service;

import edu.njust.dao.AdministratorMapper;
import edu.njust.entity.Administrator;
import edu.njust.mybatis.AdministratorDaoImpl;

public class AdministratorService {
	AdministratorMapper a =new AdministratorDaoImpl();
	   public boolean  comAdministrator(Administrator adm){
		   return a.comAdministrator(adm);
	   };
}
