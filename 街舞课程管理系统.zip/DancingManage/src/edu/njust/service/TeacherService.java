package edu.njust.service;


import java.util.List;

import edu.njust.dao.TeacherMapper;
import edu.njust.entity.Teacher;
import edu.njust.mybatis.TeacherDaoImpl;

public class TeacherService {
	TeacherMapper a1= new TeacherDaoImpl();
	public void addTeacher(Teacher teacher){
		a1.addTeacher(teacher);
	};
    public void updateTeacherPwd(Teacher teacher){
    	a1.updateTeacherPwd(teacher);
    };
    public void delTeacher(Integer account){
        a1.delTeacher(account);
    };
    public Teacher getTeacher(Integer account){
    	return a1.getTeacher(account);
    };
    public boolean  comTeacher(Teacher teacher){
    	return a1.comTeacher(teacher);
    };
    public List<Teacher> getTeachers(){
    	return a1.getTeachers();
    			
    };
    public void haveClass(Integer account){
    	a1.haveClass(account);
    };
    public void haveStu(Integer account){
    	a1.haveStu(account);
    };
    

}
