package edu.njust.dao;

import java.util.List;

import edu.njust.entity.CourseMsg;;

public interface CourseMsgMapper {
	 public void addCourseMsg1(CourseMsg cm);
	 public void delCourseMsg(CourseMsg cm);
	 public void delCourseMsg1byCourse(Integer courseid);
	 public List<CourseMsg> getCourseMsgs1(Integer account);
	 public List<CourseMsg> getCourseMsgs1Byid(Integer courseid);

}
