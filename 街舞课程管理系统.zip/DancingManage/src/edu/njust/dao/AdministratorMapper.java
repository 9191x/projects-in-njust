package edu.njust.dao;

import edu.njust.entity.Administrator;

public interface AdministratorMapper {
	   public Administrator getAdministrator(Integer account);
	   public boolean  comAdministrator(Administrator adm);

}
