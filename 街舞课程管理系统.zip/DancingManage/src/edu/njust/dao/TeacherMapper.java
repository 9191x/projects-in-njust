package edu.njust.dao;

import java.util.List;

import edu.njust.entity.Teacher;

public interface TeacherMapper {
	public void addTeacher(Teacher teacher);
    public void updateTeacherPwd(Teacher teacher);
    public void delTeacher(Integer account);
    public Teacher getTeacher(Integer account);
    public boolean  comTeacher(Teacher teacher);
    public List<Teacher> getTeachers();
    public void haveClass(Integer account);
    public void haveStu(Integer account);
}
