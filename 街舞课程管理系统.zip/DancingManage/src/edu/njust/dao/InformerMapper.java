package edu.njust.dao;

import java.util.List;

import edu.njust.entity.Informer;

public interface InformerMapper {
    public void addInformer(Informer inf);
    public void updateInformer(Informer inf);
    public void delInformer(Integer account);
    public Informer getInformer(Integer account);
    public boolean  comInformer(Informer inf);
    public List<Informer> getInformers();

}
