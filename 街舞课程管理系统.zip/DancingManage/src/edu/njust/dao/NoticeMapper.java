package edu.njust.dao;

import java.util.List;

import edu.njust.entity.Notice;

public interface NoticeMapper {
	public void addNotice(Notice notice);
    //public void updateMsg(Msg msg);
    public void delNotice(Integer id);
    //public Student getStudent(int account);
    //public boolean  comStudent(Student stu);
    public List<Notice> getNotices(Integer account);
}
