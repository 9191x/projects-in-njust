package edu.njust.dao;

import java.util.List;

import edu.njust.entity.Course;

public interface CourseMapper {
	
	public void addCourse(Course c1);
    public void delCourse(Integer id);
    public Course getCourse(Integer id);
    public void changeStatus(Integer id);
    public void changeIfdel(Integer id);
    public void returnIfdel(Integer id);
    public List<Course> getCourses();
    public void bookCourse(Integer id);
    public void resetStuNum(Integer id);
    public void delbookCourse(Integer id);
    public Integer getStatus(Integer id);
}
