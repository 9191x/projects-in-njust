package edu.njust.dao;

import java.util.List;

import edu.njust.entity.CourseMsgFin;

public interface CourseMsgFinMapper {
	 public void addCourseMsg2(CourseMsgFin cm);
	 public List<CourseMsgFin> getCourseMsgs2(Integer account);
}
