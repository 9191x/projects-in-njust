package edu.njust.dao;

import java.util.List;

import edu.njust.entity.Parent;

public interface ParentMapper {
    public void addParent(Parent par);
    public void updateParentPwd(Parent par);
    public void delParent(int account);
    public Parent getParent(int account);
    public boolean  comParent(Parent par);
    public List<Parent> getParents();
    public Parent getParentbyTel(String tel);

}
