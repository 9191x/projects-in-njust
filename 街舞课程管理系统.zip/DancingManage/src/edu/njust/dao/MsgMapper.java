package edu.njust.dao;

import java.util.List;

import edu.njust.entity.Msg;


public interface MsgMapper {
	public void addMsg(Msg msg);
    public void delMsg(int id);
    public List<Msg> getMsgs();
}
