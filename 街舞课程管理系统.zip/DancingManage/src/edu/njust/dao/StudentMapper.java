package edu.njust.dao;

import java.util.List;

import edu.njust.entity.Student;

public interface StudentMapper {
    public void addStudent(Student stu);
    public void updateStudentPwd(Student stu);
    public void delStudent(int account);
    public Student getStudent(int account);
    public boolean  comStudent(Student stu);
    public List<Student> getStudents();
    public void addClasstime1(Integer account);
    public void addClasstime2(Integer account);
    public void changeStatus9(Integer account);
    public void changeStatus1(Integer account);
    public void changeStatus2(Integer account);
    public void haveClass(Integer account);
    public Student getStudentbyTel(String phone);
    public Integer getStudentStatus(Integer account);
    public Integer getParentNum(Integer account);
    public void newParent(Integer account);
    public Student addParent(Student bb);
}
