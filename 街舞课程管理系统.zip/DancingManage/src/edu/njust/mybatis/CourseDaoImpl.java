package edu.njust.mybatis;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import edu.njust.dao.CourseMapper;
import edu.njust.dao.ParentMapper;
import edu.njust.entity.Course;
import edu.njust.utils.MyBatisUtils;

public class CourseDaoImpl implements CourseMapper{

	@Override
	public void addCourse(Course c1) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    CourseMapper mapper = openSession.getMapper(CourseMapper.class);
	    mapper.addCourse(c1);
	    openSession.commit();
        openSession.close();
		
	}

	@Override
	public void delCourse(Integer id) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    CourseMapper mapper = openSession.getMapper(CourseMapper.class);
	    mapper.delCourse(id);
	    openSession.commit();
        openSession.close();
	}

	@Override
	public Course getCourse(Integer id) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    CourseMapper mapper = openSession.getMapper(CourseMapper.class);
	    Course a1=mapper.getCourse(id);
	    openSession.close();
		return a1;
	}

	@Override
	public List<Course> getCourses() {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    CourseMapper mapper = openSession.getMapper(CourseMapper.class);
	    List<Course> a1=mapper.getCourses();
	    openSession.close();
		return a1;
	}

	@Override
	public void bookCourse(Integer id) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    CourseMapper mapper = openSession.getMapper(CourseMapper.class);
        mapper.bookCourse(id);
        openSession.commit();
        openSession.close();		
	}

	@Override
	public void delbookCourse(Integer id) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    CourseMapper mapper = openSession.getMapper(CourseMapper.class);
        mapper.delbookCourse(id);
        openSession.commit();
        openSession.close();	
	}

	@Override
	public void changeStatus(Integer id) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    CourseMapper mapper = openSession.getMapper(CourseMapper.class);
        mapper.changeStatus(id);
        openSession.commit();
        openSession.close();	
	}

	@Override
	public Integer getStatus(Integer id) {
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    CourseMapper mapper = openSession.getMapper(CourseMapper.class);
	    Integer a1=mapper.getStatus(id);
	    openSession.close();
		return a1;
	}

	@Override
	public void changeIfdel(Integer id) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    CourseMapper mapper = openSession.getMapper(CourseMapper.class);
        mapper.changeIfdel(id);
        openSession.commit();
        openSession.close();	
	}

	@Override
	public void resetStuNum(Integer id) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    CourseMapper mapper = openSession.getMapper(CourseMapper.class);
        mapper.resetStuNum(id);
        openSession.commit();
        openSession.close();	
	}

	@Override
	public void returnIfdel(Integer id) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    CourseMapper mapper = openSession.getMapper(CourseMapper.class);
        mapper.returnIfdel(id);
        openSession.commit();
        openSession.close();
	}




}
