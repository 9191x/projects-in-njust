package edu.njust.mybatis;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import edu.njust.dao.InformerMapper;
import edu.njust.dao.ParentMapper;
import edu.njust.entity.Informer;
import edu.njust.entity.Parent;
import edu.njust.utils.MyBatisUtils;


public class InformerDaoImpl implements InformerMapper{

	public void addInformer(Informer inf) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    InformerMapper mapper = openSession.getMapper(InformerMapper.class);
	    mapper.addInformer(inf);
	    openSession.commit();
        openSession.close();
	}

	@Override
	public void updateInformer(Informer inf) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    InformerMapper mapper = openSession.getMapper(InformerMapper.class);
	    mapper.updateInformer(inf);
	    openSession.commit();
        openSession.close();
	}

	@Override
	public void delInformer(Integer account) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    InformerMapper mapper = openSession.getMapper(InformerMapper.class);
	    mapper.delInformer(account);
	    openSession.commit();
        openSession.close();
		
	}

	@Override
	public Informer getInformer(Integer account) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    InformerMapper mapper = openSession.getMapper(InformerMapper.class);
	    Informer a1=mapper.getInformer(account);
         openSession.close();
		 return a1;
	}

	@Override
	public boolean comInformer(Informer inf) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    InformerMapper mapper = openSession.getMapper(InformerMapper.class);
	    Informer a1 =mapper.getInformer(inf.getAccount());
		openSession.close();
		if(a1!=null&&a1.getPwd().equals(inf.getPwd()))
			return true;
		else return false;
	}

	@Override
	public List<Informer> getInformers() {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    InformerMapper mapper = openSession.getMapper(InformerMapper.class);
	    List<Informer> aa=mapper.getInformers();			
        openSession.close();
		return aa;
	}

}
