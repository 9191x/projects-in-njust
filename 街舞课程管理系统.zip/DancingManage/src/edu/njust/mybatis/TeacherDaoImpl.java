package edu.njust.mybatis;


import java.util.List;

import org.apache.ibatis.session.SqlSession;

import edu.njust.dao.TeacherMapper;
import edu.njust.entity.Teacher;
import edu.njust.utils.MyBatisUtils;

public class TeacherDaoImpl implements TeacherMapper{

	@Override
	public void addTeacher(Teacher teacher) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    TeacherMapper mapper = openSession.getMapper(TeacherMapper.class);
	    mapper.addTeacher(teacher);
	    openSession.commit();
        openSession.close();
	}

	@Override
	public void updateTeacherPwd(Teacher teacher) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    TeacherMapper mapper = openSession.getMapper(TeacherMapper.class);
	    mapper.addTeacher(teacher);
	    openSession.commit();
        openSession.close();
		
	}

	@Override
	public void delTeacher(Integer account) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
		 TeacherMapper mapper = openSession.getMapper(TeacherMapper.class);
	     mapper.delTeacher(account);
	     openSession.commit();
        openSession.close();
	}

	@Override
	public Teacher getTeacher(Integer account) {
		// TODO Auto-generated method stub
		 SqlSession openSession = MyBatisUtils.getSqlSession();		
		 TeacherMapper mapper = openSession.getMapper(TeacherMapper.class);
	     Teacher a1=mapper.getTeacher(account);
         openSession.close();
		return a1;
	}

	@Override
	public boolean comTeacher(Teacher teacher) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
		TeacherMapper mapper = openSession.getMapper(TeacherMapper.class);
        Teacher a1 = mapper.getTeacher(teacher.getAccount());
		openSession.close();
		if(a1!=null&&a1.getPwd().equals(teacher.getPwd()))
			return true;
		else return false;
	}

	@Override
	public List<Teacher> getTeachers() {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
		TeacherMapper mapper = openSession.getMapper(TeacherMapper.class);
			List<Teacher> aa=mapper.getTeachers();			
        openSession.close();
		return aa;
		
	}

	@Override
	public void haveClass(Integer account) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    TeacherMapper mapper = openSession.getMapper(TeacherMapper.class);
	    mapper.haveClass(account);
	    openSession.commit();
        openSession.close();
	}

	@Override
	public void haveStu(Integer account) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    TeacherMapper mapper = openSession.getMapper(TeacherMapper.class);
	    mapper.haveStu(account);
	    openSession.commit();
        openSession.close();
	}
	
}
