package edu.njust.mybatis;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import edu.njust.dao.MsgMapper;
import edu.njust.entity.Msg;
import edu.njust.utils.MyBatisUtils;

public class MsgDaoImpl implements MsgMapper{
	
	@Override
	public void addMsg(Msg msg) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    MsgMapper mapper = openSession.getMapper(MsgMapper.class);
	    mapper.addMsg(msg);
	    openSession.commit();
        openSession.close();
        }

	@Override
	public List<Msg> getMsgs() {
		// TODO Auto-generated method stub
         SqlSession openSession = MyBatisUtils.getSqlSession();		
	    MsgMapper mapper = openSession.getMapper(MsgMapper.class);
			List<Msg> aa=mapper.getMsgs();			
        openSession.close();
		return aa;
	}
	
	public void delMsg(int id) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    MsgMapper mapper = openSession.getMapper(MsgMapper.class);
	    mapper.delMsg(id);
	    openSession.commit();
        openSession.close();
	}
}
