package edu.njust.mybatis;

import org.apache.ibatis.session.SqlSession;

import edu.njust.dao.AdministratorMapper;
import edu.njust.dao.CourseMapper;
import edu.njust.dao.StudentMapper;
import edu.njust.entity.Administrator;
import edu.njust.entity.Course;
import edu.njust.entity.Student;
import edu.njust.utils.MyBatisUtils;

public class AdministratorDaoImpl implements AdministratorMapper{

	@Override
	public Administrator getAdministrator(Integer account) {
		SqlSession openSession = MyBatisUtils.getSqlSession();	
		AdministratorMapper mapper = openSession.getMapper(AdministratorMapper.class);
		Administrator a1=mapper.getAdministrator(account);
		openSession.close();
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean comAdministrator(Administrator adm) {
		SqlSession openSession = MyBatisUtils.getSqlSession();		
		AdministratorMapper mapper = openSession.getMapper(AdministratorMapper.class);
		Administrator a1=mapper.getAdministrator(adm.getAccount());
		openSession.close();
		if(a1!=null&&a1.getPwd().equals(adm.getPwd()))
			return true;
		else return false;
	}

}
