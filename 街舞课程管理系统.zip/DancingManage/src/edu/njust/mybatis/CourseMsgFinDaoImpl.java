package edu.njust.mybatis;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import edu.njust.dao.CourseMsgFinMapper;
import edu.njust.entity.CourseMsgFin;
import edu.njust.utils.MyBatisUtils;

public class CourseMsgFinDaoImpl implements CourseMsgFinMapper{

	@Override
	public void addCourseMsg2(CourseMsgFin cm) {
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    CourseMsgFinMapper mapper = openSession.getMapper(CourseMsgFinMapper.class);
	    mapper.addCourseMsg2(cm);
	    openSession.commit();
        openSession.close();
	}

	@Override
	public List<CourseMsgFin> getCourseMsgs2(Integer account) {
		SqlSession openSession = MyBatisUtils.getSqlSession();		
		 CourseMsgFinMapper mapper = openSession.getMapper(CourseMsgFinMapper.class);
	    List<CourseMsgFin> a1=mapper.getCourseMsgs2(account);
	    openSession.close();
		return a1;
	}

}
