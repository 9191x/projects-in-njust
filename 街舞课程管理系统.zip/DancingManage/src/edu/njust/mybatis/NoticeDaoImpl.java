package edu.njust.mybatis;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import edu.njust.dao.MsgMapper;
import edu.njust.dao.NoticeMapper;
import edu.njust.entity.Notice;
import edu.njust.utils.MyBatisUtils;

public class NoticeDaoImpl implements NoticeMapper{

	@Override
	public void addNotice(Notice notice) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    NoticeMapper mapper = openSession.getMapper(NoticeMapper.class);
	    mapper.addNotice(notice);
	    openSession.commit();
        openSession.close();
	}

	@Override
	public void delNotice(Integer id) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    NoticeMapper mapper = openSession.getMapper(NoticeMapper.class);
	    mapper.delNotice(id);
	    openSession.commit();
        openSession.close();
	}

	@Override
	public List<Notice> getNotices(Integer account) {
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    NoticeMapper mapper = openSession.getMapper(NoticeMapper.class);
	    List<Notice> nt =mapper.getNotices(account);
	    
	    openSession.close();
	    return nt;
	    
        
	}

}
