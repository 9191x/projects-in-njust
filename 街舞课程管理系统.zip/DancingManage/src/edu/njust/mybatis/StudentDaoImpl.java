package edu.njust.mybatis;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.Test;

import edu.njust.dao.StudentMapper;
import edu.njust.entity.Student;
import edu.njust.utils.MyBatisUtils;

public class StudentDaoImpl implements StudentMapper{
	@Override
	public void addStudent(Student stu) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    StudentMapper mapper = openSession.getMapper(StudentMapper.class);
	    mapper.addStudent(stu);
	    openSession.commit();
        openSession.close();
        }
	

	@Override
	public void updateStudentPwd(Student stu) {
		//
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    StudentMapper mapper = openSession.getMapper(StudentMapper.class);
	    mapper.addStudent(stu);
	    openSession.commit();
        openSession.close();
		
	}

	@Override
	public void delStudent(int account) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    StudentMapper mapper = openSession.getMapper(StudentMapper.class);
	    mapper.delStudent(account);
	    openSession.commit();
        openSession.close();
	}
	@Override
	public Student getStudent(int account) {
		// TODO Auto-generated method stub
         SqlSession openSession = MyBatisUtils.getSqlSession();		
	     StudentMapper mapper = openSession.getMapper(StudentMapper.class);
	     Student a1=mapper.getStudent(account);
         openSession.close();
		 return a1;
	}
	
	@Override
	public Student getStudentbyTel(String phone) {
		// TODO Auto-generated method stub
         SqlSession openSession = MyBatisUtils.getSqlSession();		
	     StudentMapper mapper = openSession.getMapper(StudentMapper.class);
	     Student a1=mapper.getStudentbyTel(phone);
         openSession.close();
		 return a1;
	}
	
	@Override
	public List<Student> getStudents() {
		// TODO Auto-generated method stub
         SqlSession openSession = MyBatisUtils.getSqlSession();		
	    StudentMapper mapper = openSession.getMapper(StudentMapper.class);
			List<Student> aa=mapper.getStudents();			
        openSession.close();
		return aa;
	}


	@Override
	public boolean comStudent(Student stu) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    StudentMapper mapper = openSession.getMapper(StudentMapper.class);
        Student a1 = mapper.getStudent(stu.getAccount());
		openSession.close();
		if(a1!=null&&a1.getPwd().equals(stu.getPwd()))
			return true;
		else return false;
	}


	@Override
	public void addClasstime1(Integer account) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    StudentMapper mapper = openSession.getMapper(StudentMapper.class);
	    mapper.addClasstime1(account);
	    openSession.commit();
        openSession.close();
	}


	@Override
	public void addClasstime2(Integer account) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    StudentMapper mapper = openSession.getMapper(StudentMapper.class);
	    mapper.addClasstime2(account);
	    openSession.commit();
        openSession.close();
	}


	@Override
	public void changeStatus9(Integer account) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    StudentMapper mapper = openSession.getMapper(StudentMapper.class);
	    mapper.changeStatus9(account);
	    openSession.commit();
        openSession.close();
	}


	@Override
	public void haveClass(Integer account) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    StudentMapper mapper = openSession.getMapper(StudentMapper.class);
	    mapper.haveClass(account);
	    openSession.commit();
        openSession.close();
	}


	@Override
	public void changeStatus1(Integer account) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    StudentMapper mapper = openSession.getMapper(StudentMapper.class);
	    mapper.changeStatus1(account);
	    openSession.commit();
        openSession.close();
	}


	@Override
	public void changeStatus2(Integer account) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    StudentMapper mapper = openSession.getMapper(StudentMapper.class);
	    mapper.changeStatus2(account);
	    openSession.commit();
        openSession.close();
	}


	@Override
	public Integer getStudentStatus(Integer account) {
		// TODO Auto-generated method stub
		 SqlSession openSession = MyBatisUtils.getSqlSession();		
	     StudentMapper mapper = openSession.getMapper(StudentMapper.class);
	     Integer a1=mapper.getStudentStatus(account);
         openSession.close();
		 return a1;
	}


	@Override
	public Integer getParentNum(Integer account) {
		// TODO Auto-generated method stub
		 SqlSession openSession = MyBatisUtils.getSqlSession();		
	     StudentMapper mapper = openSession.getMapper(StudentMapper.class);
	     Integer a1=mapper.getParentNum(account);
         openSession.close();
		 return a1;
	}


	@Override
	public void newParent(Integer account) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    StudentMapper mapper = openSession.getMapper(StudentMapper.class);
	    mapper.newParent(account);
	    openSession.commit();
        openSession.close();
	}


	@Override
	public Student addParent(Student bb) {
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    StudentMapper mapper = openSession.getMapper(StudentMapper.class);
	    Student d = mapper.addParent(bb);
	    openSession.commit();
        openSession.close();
		return d;
		// TODO Auto-generated method stub
		
	}

	
    }

