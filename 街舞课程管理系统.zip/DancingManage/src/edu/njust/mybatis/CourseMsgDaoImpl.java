package edu.njust.mybatis;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import edu.njust.dao.CourseMapper;
import edu.njust.dao.CourseMsgMapper;
import edu.njust.entity.Course;
import edu.njust.entity.CourseMsg;
import edu.njust.utils.MyBatisUtils;

public class CourseMsgDaoImpl implements CourseMsgMapper{

	@Override
	public void addCourseMsg1(CourseMsg cm) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    CourseMsgMapper mapper = openSession.getMapper(CourseMsgMapper.class);
	    mapper.addCourseMsg1(cm);
	    openSession.commit();
        openSession.close();
	}



	@Override
	public void delCourseMsg(CourseMsg cm) {
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    CourseMsgMapper mapper = openSession.getMapper(CourseMsgMapper.class);
	    mapper.delCourseMsg(cm);
	    openSession.commit();
        openSession.close();
		
	}

	@Override
	public void delCourseMsg1byCourse(Integer courseid) {
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    CourseMsgMapper mapper = openSession.getMapper(CourseMsgMapper.class);
	    mapper.delCourseMsg1byCourse(courseid);
	    openSession.commit();
        openSession.close();
		
	}

	@Override
	public List<CourseMsg> getCourseMsgs1(Integer account) {
		SqlSession openSession = MyBatisUtils.getSqlSession();		
		 CourseMsgMapper mapper = openSession.getMapper(CourseMsgMapper.class);
	    List<CourseMsg> a1=mapper.getCourseMsgs1(account);
	    openSession.close();
		return a1;
	}

	

	@Override
	public List<CourseMsg> getCourseMsgs1Byid(Integer courseid) {
		SqlSession openSession = MyBatisUtils.getSqlSession();		
		 CourseMsgMapper mapper = openSession.getMapper(CourseMsgMapper.class);
	    List<CourseMsg> a1=mapper.getCourseMsgs1Byid(courseid);
	    openSession.close();
		return a1;
	}

}
