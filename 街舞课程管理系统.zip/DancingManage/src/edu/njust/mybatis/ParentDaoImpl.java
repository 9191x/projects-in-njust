package edu.njust.mybatis;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import edu.njust.dao.ParentMapper;
import edu.njust.dao.StudentMapper;
import edu.njust.entity.Parent;
import edu.njust.entity.Student;
import edu.njust.utils.MyBatisUtils;

public class ParentDaoImpl implements ParentMapper {

	@Override
	public void addParent(Parent par) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    ParentMapper mapper = openSession.getMapper(ParentMapper.class);
	    mapper.addParent(par);
	    openSession.commit();
        openSession.close();
	}

	@Override
	public void updateParentPwd(Parent par) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    ParentMapper mapper = openSession.getMapper(ParentMapper.class);
	    mapper.addParent(par);
	    openSession.commit();
        openSession.close();
	}

	@Override
	public void delParent(int account) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    ParentMapper mapper = openSession.getMapper(ParentMapper.class);
	    mapper.delParent(account);
	    System.out.println(account);
	    openSession.commit();
        openSession.close();
		
	}

	@Override
	public Parent getParent(int account) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    ParentMapper mapper = openSession.getMapper(ParentMapper.class);
		 Parent a1=mapper.getParent(account);
         openSession.close();
		 return a1;
	}
	@Override
	public Parent getParentbyTel(String phone) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    ParentMapper mapper = openSession.getMapper(ParentMapper.class);
	    Parent b1 = mapper.getParentbyTel(phone);
        openSession.close();
        return b1;
	}

	@Override
	public boolean comParent(Parent par) {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    ParentMapper mapper = openSession.getMapper(ParentMapper.class);
	    Parent a1 = mapper.getParent(par.getAccount());
		openSession.close();
		if(a1!=null&&a1.getPwd().equals(par.getPwd()))
			return true;
		else return false;
	}

	@Override
	public List<Parent> getParents() {
		// TODO Auto-generated method stub
		SqlSession openSession = MyBatisUtils.getSqlSession();		
	    ParentMapper mapper = openSession.getMapper(ParentMapper.class);
		List<Parent> aa=mapper.getParents();			
        openSession.close();
		return aa;
	}

	

}
