package edu.njust.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.njust.entity.Administrator;
import edu.njust.entity.Informer;
import edu.njust.entity.Parent;
import edu.njust.entity.Student;
import edu.njust.entity.Teacher;
import edu.njust.service.AdministratorService;
import edu.njust.service.InformerService;
import edu.njust.service.ParentService;
import edu.njust.service.StudentService;
import edu.njust.service.TeacherService;
import edu.njust.utils.DateUtils;

public class ManageAccountServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public ManageAccountServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8"); 
		request.setCharacterEncoding("UTF-8");
		
		String button = request.getParameter("button");
		
		if(button.equals("登录")){
			HttpSession session1 = request.getSession();
	        String checkcode = (String)session1.getAttribute("CKECKCODE");
	        String code = request.getParameter("checkcode");
	        if(checkcode == null || (code.equals(checkcode)==false)){
	        	PrintWriter out = response.getWriter();
	        	out.print("<script>alert('验证码不正确，请重新登录'); window.location='login.jsp' </script>");
	        	out.flush();
	        	out.close();
	        }
	        else {
	        	int account = Integer.parseInt(request.getParameter("uaccount"));
	            String pwd = request.getParameter("upwd");
	            if(account>=50000000&&account<80000000){//学生
	            	StudentService studentService = new StudentService();
		            
		            //System.out.println(accstatus);
		            Student stu=new Student(account,pwd);
		            boolean loginresult = studentService.comStudent(stu);
		            if(loginresult==false){
		            	PrintWriter out = response.getWriter();
    		        	out.print("<script>alert('用户名或密码错误，请重新登录...'); window.location='login.jsp' </script>");
    		        	out.flush();
    		        	out.close();
		            }
		            else if(loginresult==true){
		            	int accstatus = studentService.getStudentStatus(account);
		            	if(accstatus==0){
			            	PrintWriter out = response.getWriter();
				        	out.print("<script>alert('请等待管理员审核后登录'); window.location='login.jsp' </script>");
				        	out.flush();
				        	out.close();
			            }
		            	else {
		            		String account1=String.valueOf(account);
			            	HttpSession session=request.getSession();
			    	        session.setAttribute("useraccount",account1);
			             request.getRequestDispatcher("ManageCourseServlet?param=21").forward(request,response);
		            	}
		            }
	            }
	            else if(account>=80000000){//家长
	            	ParentService parentService=new ParentService();
    		        Parent par=new Parent(account,pwd);
    		        boolean loginresult = parentService.comParent(par);
    		        if(loginresult==true){
    		        	 String account1=String.valueOf(account);
    		         	HttpSession session=request.getSession();
    		 	        session.setAttribute("useraccount",account1);
    		          request.getRequestDispatcher("ManageInforServlet?param=41").forward(request,response);	
    		        }
    		        else{
    		        	PrintWriter out = response.getWriter();
    		        	out.print("<script>alert('用户名或密码错误，请重新登录...'); window.location='login.jsp' </script>");
    		        	out.flush();
    		        	out.close();
    		        }
	            }
	            else if(account>=40000000){//老师
	            	TeacherService TeacherService=new TeacherService();
			        Teacher t=new Teacher(account,pwd);
			        boolean loginresult = TeacherService.comTeacher(t);
			        if(loginresult==true){
			        String account1=String.valueOf(account);
			        HttpSession session=request.getSession();
			        session.setAttribute("useraccount",account1);
			         request.getRequestDispatcher("ManageCourseServlet?param=11").forward(request,response);	
			        }
			        else{
			        	PrintWriter out = response.getWriter();
			        	out.print("<script>alert('用户名或密码错误，请重新登录...'); window.location='login.jsp' </script>");
			        	out.flush();
			        	out.close();
			        }
	            }
	            else if(account>=20000000){//通知管理员
	            	InformerService informerService=new InformerService();
			        Informer  inf=new Informer(account,pwd);
			        boolean loginresult = informerService.comInformer(inf);
			        if(loginresult==true){
			        String account1=String.valueOf(account);
			        HttpSession session=request.getSession();
			        session.setAttribute("useraccount",account1);
			         request.getRequestDispatcher("ManageCourseServlet?param=31").forward(request,response);	
			        }
			        else{
			        	PrintWriter out = response.getWriter();
			        	out.print("<script>alert('用户名或密码错误，请重新登录...'); window.location='login.jsp' </script>");
			        	out.flush();
			        	out.close();
			        }
	            }
	            else if(account<=100000){//系统管理员
	            	AdministratorService ad=new AdministratorService();
			        Administrator a1 =new Administrator(account,pwd);
			        boolean loginresult = ad.comAdministrator(a1);
			        if(loginresult==true){
			        String account1=String.valueOf(account);
			        HttpSession session=request.getSession();
			        session.setAttribute("useraccount",account1);
			         request.getRequestDispatcher("ManagePeopleServlet?param=1").forward(request,response);	
			        }
			        else{
			        	PrintWriter out = response.getWriter();
			        	out.print("<script>alert('用户名或密码错误，请重新登录...'); window.location='login.jsp' </script>");
			        	out.flush();
			        	out.close();
			        }
	            }
	            else
	            {
	            	PrintWriter out = response.getWriter();
		        	out.print("<script>alert('用户名或密码错误，请重新登录...'); window.location='login.jsp' </script>");
		        	out.flush();
		        	out.close();
	            }
	        }
		}
		else if(button.equals("学生注册")){
			String name = request.getParameter("name");
	        String pwd = request.getParameter("userpwd");
	        String pwd1 = request.getParameter("userpwd1");
	        Date brithday = (Date) DateUtils.getDate(request.getParameter("birthday"));
	        String email = request.getParameter("email");
	        String phone = request.getParameter("phone");
			Student sss=new Student(name, pwd, brithday, email,phone);
			
			if(pwd.equals(pwd1)==false){

	        	PrintWriter out = response.getWriter();
	        	out.print("<script>alert('密码错误，请确认两次输入密码相同'); window.location='register1.jsp' </script>");
	        	out.flush();
	        	out.close();
	        }
			else if(pwd.equals(pwd1)){
				StudentService studentService=new StudentService();
				Student student0 = studentService.getStudentbyTel(phone);
				if(student0!=null&&(student0.getAccount()>=50000000&&student0.getAccount()<80000000)){
					PrintWriter out = response.getWriter();
		        	out.print("<script>alert('该手机号码已注册，请更换手机号码后重新注册'); window.location='register1.jsp' </script>");
		        	out.flush();
		        	out.close();
				}
				else if(student0==null){
					if(sss.getBrithday()==null||sss.getEmail()==null||sss.getEmail()==""||
							sss.getPhone()==null||sss.getPhone()==""||sss.getPwd()==null||sss.getPwd()==""||
							sss.getName()==null||sss.getName()==""){
						PrintWriter out = response.getWriter();
			        	out.print("<script>alert('请将信息填写完整后重新注册'); window.location='register1.jsp' </script>");
			        	out.flush();
			        	out.close();
					}
					else{
						studentService.addStudent(sss);
						Student student = studentService.getStudentbyTel(phone);
						int temp = student.getAccount();
						PrintWriter out = response.getWriter();
			        	out.print("<script>alert('注册成功，你的账号是："+temp+"'); window.location='login.jsp' </script>");

					}
				}
			}
		}
		else if(button.equals("家长注册")){
			
	        //System.out.println("111="+request.getAttribute("childaccount"));
	        if(request.getParameter("childaccount")==""){
	        	PrintWriter out = response.getWriter();
	        	out.print("<script>alert('请将信息填写完整后重新注册'); window.location='register2.jsp' </script>");
	        	out.flush();
	        	out.close();
	        }
	        else{
	        	String name = request.getParameter("name");
		        String pwd = request.getParameter("userpwd");
		        String pwd1 = request.getParameter("userpwd1");
	        	Integer childaccount = Integer.parseInt(request.getParameter("childaccount"));
		        String childname = request.getParameter("childname");
		        String email = request.getParameter("email");
		        String phone = request.getParameter("phone");
		        //System.out.println("acc="+childaccount);
				Parent sss=new Parent(name, pwd, childaccount, childname, email,phone);
				
				if(pwd.equals(pwd1)==false){
					
		        	PrintWriter out = response.getWriter();
		        	out.print("<script>alert('请确认两次输入密码相同'); window.location='register2.jsp' </script>");
		        	out.flush();
		        	out.close();
		        }
				else if(pwd.equals(pwd1)){
					
					StudentService studentservice = new StudentService();
					Student bbb =new Student(childname,"111",childaccount);
					boolean is = studentservice.addParent(bbb);
					if(is==false){
			        	PrintWriter out = response.getWriter();
			        	out.print("<script>alert('孩子的帐号和姓名有误，请重新填写后注册'); window.location='register2.jsp' </script>");
			        	out.flush();
			        	out.close();
					}
					else{
						ParentService parentService=new ParentService();
						Parent parent0 = parentService.getParentbyTel(phone);
						if(parent0!=null&&(parent0.getAccount()>=80000000&&parent0.getAccount()<=99999999)){
							PrintWriter out = response.getWriter();
				        	out.print("<script>alert('该手机号码已注册，请更换手机号码后重新注册'); window.location='register2.jsp' </script>");
				        	out.flush();
				        	out.close();
						}
						else if(parent0==null){
							if(sss.getChind_name()==null||sss.getChind_name()==""||sss.getEmail()==null||sss.getEmail()==""||sss.getName()==null||sss.getName()==""||
									sss.getPhone()==null||sss.getPhone()==""||sss.getPwd()==null||sss.getPwd()==""){
								PrintWriter out = response.getWriter();
					        	out.print("<script>alert('请将信息填写完整后重新注册'); window.location='register2.jsp' </script>");
					        	out.flush();
					        	out.close();
							}
							else{
								//parentService.addParent(sss);
								//System.out.println("添加");
								StudentService studentService = new StudentService();
								//studentService.newParent(sss.getChind_account());
								//System.out.println("更新");
								
								int times = studentService.getParentNum(sss.getChind_account());
								System.out.println("yes");
								if(times<=0){
									System.out.println("times<0");
									//parentService.delParent(sss.getAccount());
									PrintWriter out = response.getWriter();
						        	out.print("<script>alert('你孩子所允许注册的家长帐号已满，请更换孩子帐号后重新注册'); window.location='register2.jsp' </script>");
						        	out.flush();
						        	out.close();
								}
								else if(times>0){
									parentService.addParent(sss);
									studentService.newParent(sss.getChind_account());
									System.out.println("times>=0");
									Parent parent = parentService.getParentbyTel(phone);
									System.out.println("错误");
									int temp = parent.getAccount();
									PrintWriter out = response.getWriter();
						        	out.print("<script>alert('注册成功，你的账号是："+temp+"'); window.location='login.jsp' </script>");
								}
							}	
						}
					}	
				}
	        } 
		}
	 } 

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
