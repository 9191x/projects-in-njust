package edu.njust.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.njust.entity.Course;
import edu.njust.entity.CourseMsg;
import edu.njust.entity.CourseMsgFin;
import edu.njust.entity.Notice;
import edu.njust.entity.Teacher;
import edu.njust.service.CourseMsgService;
import edu.njust.service.CourseService;
import edu.njust.service.NoticeService;
import edu.njust.service.TeacherService;
public class ManageCourseServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	
	public ManageCourseServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8"); 
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String param=request.getParameter("param");
		System.out.print("param+"+param);
		 if(param.equals("toaddcourse")){
			 request.getRequestDispatcher("addCourse.jsp").forward(request,response);
		 }
		else if(param.equals("11")||param.equals("addcourse")){
		if(param.equals("addcourse")){
			HttpSession session=request.getSession();
			Integer account=Integer.parseInt((String)session.getAttribute("useraccount"));
			
			
			if(request.getParameter("type")!=""&&request.getParameter("courseid")!=""){
			String type =request.getParameter("type");	
			
			Integer id=Integer.parseInt(request.getParameter("courseid"));
			CourseService cs=new CourseService();
			CourseMsgService cmg= new CourseMsgService();
			List<CourseMsg> cousg =cmg.getCourseMsgs1(account);
			boolean flagg =false;
			for(CourseMsg aa:cousg){
				if(id-aa.getCourseid()>=-2&&id-aa.getCourseid()<=2){
					flagg=true;
				}
			}
			if(!((id>=131&&id<=133)||(id>=141&&id<=143)||(id>=231&&id<=233)
					||(id>=241&&id<=243)||(id>=331&&id<=333)||(id>=341&&id<=343)||
					(id>=431&&id<=433)||(id>=441&&id<=443)||(id>=531&&id<=533)||(id>=541&&id<=543)||
					(id>=611&&id<=613)||(id>=621&&id<=623)||(id>=631&&id<=633)||
					(id>=641&&id<=643)||(id>=711&&id<=713)||(id>=721&&id<=723)||(id>=731&&id<=733)||
					(id>=741&&id<=743))){
				request.setAttribute("param1","3");
			}
			else if(flagg){
				request.setAttribute("param1","5");
			}
			else if(cs.getStatus(id)==1)
			{
				
				request.setAttribute("param1","1");
			}
			else if(cs.getCourse(id).getCourseifdel()==1){
				request.setAttribute("param1","2");
			}
			else{
			TeacherService a1=new TeacherService();
			Teacher t=a1.getTeacher(account);
			String name=t.getName();
			Course cou =new Course(id,type,name,account);
			CourseMsg coumsg=new CourseMsg(id,account);
			cmg.addCourseMsg1(coumsg);
			cs.delCourse(id);
			cs.addCourse(cou);
			request.setAttribute("param1","4");
			}}
		}
        CourseService a=new CourseService();
		List<Course> course=a.getCourses();
		request.getSession().setAttribute("course", course);;
		request.getRequestDispatcher("Teacher1.jsp").forward(request,response);
		}
		else if(param.equals("12")||param.equals("delcourse")){
			HttpSession session=request.getSession();
			Integer account=Integer.parseInt((String)session.getAttribute("useraccount"));
			if(param.equals("delcourse")){
				Integer id=Integer.parseInt(request.getParameter("id"));
				CourseService cs=new CourseService();
				CourseMsgService cmg= new CourseMsgService();
				CourseMsg aaa =new CourseMsg(id,account);
				cmg.delCourseMsg(aaa);
				cs.changeStatus(id);
				cs.changeIfdel(id);
 
			}
			CourseMsgService a1=new CourseMsgService();
			List<CourseMsg> courseMsg=a1.getCourseMsgs1(account);
			 CourseService a=new CourseService();
			 List<Course> courseList=new ArrayList<Course>(); 
			for(CourseMsg cc:courseMsg){
				Integer id=cc.getCourseid();
				Course c1=a.getCourse(id);
			    courseList.add(c1);	
			}
			List<Course> course=a.getCourses();
			request.getSession().setAttribute("courseList", courseList);
			request.getRequestDispatcher("Teacher2.jsp").forward(request,response);
			}
		else if(param.equals("14")||param.equals("delNotice")){
			HttpSession session=request.getSession();
			Integer account=Integer.parseInt((String)session.getAttribute("useraccount"));
			if(param.equals("delNotice")){
				Integer id=Integer.parseInt(request.getParameter("id"));
				NoticeService ns =new NoticeService();
				ns.delNotice(id);
			}
			NoticeService ns =new NoticeService();
			List<Notice> n1=ns.getNotices(account);
			request.getSession().setAttribute("noticelist",n1);
			request.getRequestDispatcher("Teacher4.jsp").forward(request,response);
			}
		else if(param.equals("13")){
			HttpSession session=request.getSession();
			Integer account=Integer.parseInt((String)session.getAttribute("useraccount"));
			CourseMsgService a1=new CourseMsgService();
			List<CourseMsgFin> courseMsgFin=a1.getCourseMsgs2(account);
			request.getSession().setAttribute("courseListfin", courseMsgFin);
			request.getRequestDispatcher("Teacher3.jsp").forward(request,response);
			}
			
		else if(param.equals("tobookcourse")){
			request.getRequestDispatcher("bookCourse.jsp").forward(request,response);
		}
		 
		else if(param.equals("21")||param.equals("bookcourse")){
			HttpSession session=request.getSession();
			Integer account=Integer.parseInt((String)session.getAttribute("useraccount"));
			if(param.equals("bookcourse")){
				if(request.getParameter("courseid")!=""){
				Integer id=Integer.parseInt(request.getParameter("courseid"));
				System.out.println("id是"+id);
				CourseService cs=new CourseService();
				CourseMsgService cmg= new CourseMsgService();
				CourseMsg aaa =new CourseMsg(id,account);
                List<CourseMsg> bbb=cmg.getCourseMsgs1(account);
                boolean flag=true;
                for(CourseMsg b1:bbb){
                	if(id-b1.getCourseid()>=-2&&id-b1.getCourseid()<=2){
                		flag=false;
                	}
                }
                System.out.print("flag"+flag);
              
               if(!((id>=131&&id<=133)||(id>=141&&id<=143)||(id>=231&&id<=233)
   					||(id>=241&&id<=243)||(id>=331&&id<=333)||(id>=341&&id<=343)||
   					(id>=431&&id<=433)||(id>=441&&id<=443)||(id>=531&&id<=533)||(id>=541&&id<=543)||
   					(id>=611&&id<=613)||(id>=621&&id<=623)||(id>=631&&id<=633)||
   					(id>=641&&id<=643)||(id>=711&&id<=713)||(id>=721&&id<=723)||(id>=731&&id<=733)||
   					(id>=741&&id<=743))){
            	   request.setAttribute("param2","3");
   			}
               
               else if(flag&&cs.getCourse(id).getCoursestatus()==1){
            	   cmg.addCourseMsg1(aaa);
            	   cs.bookCourse(id);
            	   request.setAttribute("param2","2");
               }
               else
               {
            	   request.setAttribute("param2","1");
               }
			   }
		}
			CourseService a=new CourseService();
			List<Course> course=a.getCourses();
			request.getSession().setAttribute("course", course);;
			request.getRequestDispatcher("student.jsp").forward(request,response);
				}
		else if(param.equals("22")||param.equals("delbookcourse")){
			HttpSession session=request.getSession();
			Integer account=Integer.parseInt((String)session.getAttribute("useraccount"));
			if(param.equals("delbookcourse")){
				Integer id=Integer.parseInt(request.getParameter("id"));
				System.out.println("id"+id);
				CourseService cs=new CourseService();
				CourseMsgService cmg= new CourseMsgService();
				CourseMsg aaa =new CourseMsg(id,account);
				System.out.print(aaa.toString());
				cmg.delCourseMsg(aaa);
	            cs.delbookCourse(id);
			}
			CourseMsgService a1=new CourseMsgService();
			List<CourseMsg> courseMsg=a1.getCourseMsgs1(account);
			 CourseService a=new CourseService();
			 List<Course> courseList=new ArrayList<Course>(); 
			for(CourseMsg cc:courseMsg){
				Integer id=cc.getCourseid();
				Course c1=a.getCourse(id);
			    courseList.add(c1);	
			    System.out.println(c1);
			}
			List<Course> course=a.getCourses();
			request.getSession().setAttribute("courseList", courseList);
			request.getRequestDispatcher("Student1.jsp").forward(request,response);
			}
		
		else if(param.equals("26")){
			HttpSession session=request.getSession();
			Integer account=Integer.parseInt((String)session.getAttribute("useraccount"));
			CourseMsgService a1=new CourseMsgService();
			List<CourseMsgFin> coursemsgfin=a1.getCourseMsgs2(account);
			request.getSession().setAttribute("courseListfin", coursemsgfin);
			request.getRequestDispatcher("Student4.jsp").forward(request,response);
			}
			
		else if(param.equals("31")){
			 List<Course> courseList=new ArrayList<Course>(); 
			CourseService a =new CourseService();
			List<Course> course=a.getCourses();
			for(Course cc:course){
				if(cc.getCoursestatus()==1)
			    courseList.add(cc);	
			}
			request.getSession().setAttribute("courselist1", courseList);
			request.getRequestDispatcher("infor1.jsp").forward(request,response);
			}
		else if(param.equals("32")){
			 List<Course> courseList=new ArrayList<Course>(); 
			CourseService a =new CourseService();
			List<Course> course=a.getCourses();
			for(Course cc:course){
				if(cc.getCourseifdel()==1)
			    courseList.add(cc);	
			}
			request.getSession().setAttribute("courselist1", courseList);
			request.getRequestDispatcher("infor2.jsp").forward(request,response);
			}
		else if(param.equals("getclassbypar")){
			CourseService a=new CourseService();
			List<Course> course=a.getCourses();
			request.getSession().setAttribute("course", course);;
			request.getRequestDispatcher("Parent2.jsp").forward(request,response);
		}
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
