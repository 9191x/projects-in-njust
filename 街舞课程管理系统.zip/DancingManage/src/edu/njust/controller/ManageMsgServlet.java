package edu.njust.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.njust.entity.Course;
import edu.njust.entity.CourseMsg;
import edu.njust.entity.Informer;
import edu.njust.entity.Msg;
import edu.njust.entity.Notice;
import edu.njust.entity.Parent;
import edu.njust.entity.Student;
import edu.njust.entity.Teacher;
import edu.njust.service.CourseMsgService;
import edu.njust.service.CourseService;
import edu.njust.service.InformerService;
import edu.njust.service.MsgService;
import edu.njust.service.NoticeService;
import edu.njust.service.ParentService;
import edu.njust.service.StudentService;
import edu.njust.service.TeacherService;
import edu.njust.utils.DateUtils;

public class ManageMsgServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public ManageMsgServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8"); 
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		

		String param=request.getParameter("param");
		if(param==null)
			param = "1";
			
		if(param.equals("0"))
		{

			MsgService c=new MsgService();
			List<Msg> msg=c.getMsgs();
			request.getSession().setAttribute("msg", msg);
			request.getRequestDispatcher("showMsg1.jsp").forward(request,response);	

		}
		else if(param.equals("1"))
		{

			MsgService c=new MsgService();
			List<Msg> msg=c.getMsgs();
			request.getSession().setAttribute("msg", msg);
			request.getRequestDispatcher("homepage.jsp").forward(request,response);	

		}
		else if(param.equals("2")){
			CourseService a=new CourseService();
			List<Course> course=a.getCourses();
			request.getSession().setAttribute("course", course);;
			request.getRequestDispatcher("student.jsp").forward(request,response);
		}
		else if(param.equals("4")){
			CourseService a=new CourseService();
			List<Course> course=a.getCourses();
			request.getSession().setAttribute("course", course);;
			request.getRequestDispatcher("Teacher1.jsp").forward(request,response);
		}
		else if(param.equals("6")){
			StudentService c=new StudentService();
			List<Student> stu=c.getStudents();
			request.getSession().setAttribute("student", stu);
			request.getRequestDispatcher("manager.jsp").forward(request,response);
		}
		else if(param.equals("7")){
			TeacherService a=new TeacherService();
			List<Teacher> tea=a.getTeachers();		
			
			request.getSession().setAttribute("teacher", tea);
			request.getRequestDispatcher("manager1.jsp").forward(request,response);
		}
		else if(param.equals("8")){
			ParentService a=new ParentService();

			List<Parent> par=a.getParents();			
			request.getSession().setAttribute("parent", par);

			request.getRequestDispatcher("manager2.jsp").forward(request,response);

		}
		else if(param.equals("9")){
			InformerService a=new InformerService();
    		
			List<Informer> inf=a.getInformers();			
			request.getSession().setAttribute("informer", inf);
			request.getRequestDispatcher("manager3.jsp").forward(request,response);
		}
		else if(param.equals("10")||param.equals("11")){
			
			MsgService a=new MsgService();
			if(param.equals("11")){

				Integer id = Integer.parseInt(request.getParameter("id"));
				a.delMsg(id);

			}
			
			MsgService b=new MsgService();
			List<Msg> msg=b.getMsgs();
			request.getSession().setAttribute("msg", msg);
			request.getRequestDispatcher("showMsg4.jsp").forward(request,response);
		}
		else if(param.equals("3")){
			String name = request.getParameter("name2");
	        String context =request.getParameter("context2");
			Msg sss=new Msg(name, context);
			if(sss.getName()!=null&&sss.getName()!=""&&sss.getContext()!=null&&sss.getContext()!=""){
				MsgService msgService=new MsgService();
				msgService.addMsg(sss);
				MsgService b=new MsgService();
				List<Msg> msg=b.getMsgs();
				request.getSession().setAttribute("msg", msg);
				request.getRequestDispatcher("showMsg2.jsp").forward(request,response);
			}
			else{
				MsgService b=new MsgService();
				List<Msg> msg=b.getMsgs();
				request.getSession().setAttribute("msg", msg);
				request.getRequestDispatcher("showMsg2.jsp").forward(request,response);
			}
		}
		else if(param.equals("5")){
			String name = request.getParameter("name3");
	        String context = request.getParameter("context3");
			Msg sss=new Msg(name, context);
			if(sss.getName()!=null&&sss.getName()!=""&&sss.getContext()!=null&&sss.getContext()!=""){
				MsgService msgService=new MsgService();
				msgService.addMsg(sss);
				MsgService b=new MsgService();
				List<Msg> msg=b.getMsgs();
				request.getSession().setAttribute("msg", msg);
				request.getRequestDispatcher("showMsg3.jsp").forward(request,response);
			}
			else{
				MsgService b=new MsgService();
				List<Msg> msg=b.getMsgs();
				request.getSession().setAttribute("msg", msg);
				request.getRequestDispatcher("showMsg3.jsp").forward(request,response);
			}
		}	
		else if(param.equals("16")){
			
			String name = request.getParameter("name3");
	        String context = request.getParameter("context3");
			Msg sss=new Msg(name, context);
			if(sss.getName()!=null&&sss.getName()!=""&&sss.getContext()!=null&&sss.getContext()!=""){
				MsgService msgService=new MsgService();
				msgService.addMsg(sss);
				MsgService b=new MsgService();
				List<Msg> msg=b.getMsgs();
				request.getSession().setAttribute("msg", msg);
				request.getRequestDispatcher("showMsg5.jsp").forward(request,response);
			}
			else{
				MsgService b=new MsgService();
				List<Msg> msg=b.getMsgs();
				request.getSession().setAttribute("msg", msg);
				request.getRequestDispatcher("showMsg5.jsp").forward(request,response);
			}
		}
		/*else if(param.equals("17")){
			//System.out.print("进入");
			String name = request.getParameter("name0");
	        String context = request.getParameter("context0");
	       // System.out.print(context0);
	       // System.out.print(context);
			Msg sss=new Msg(name, context);
			//System.out.print("封装");
			if(sss.getName()!=null&&sss.getContext()!=null){
				MsgService msgService=new MsgService();
				msgService.addMsg(sss);
				//System.out.print("添加");
				MsgService b=new MsgService();
				List<Msg> msg=b.getMsgs();
				request.getSession().setAttribute("msg", msg);
				request.getRequestDispatcher("showMsg5.jsp").forward(request,response);
		     }
		}*/
		
		
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
