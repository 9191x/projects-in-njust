package edu.njust.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.njust.entity.Course;
import edu.njust.entity.CourseMsg;
import edu.njust.entity.CourseMsgFin;
import edu.njust.entity.Notice;
import edu.njust.entity.Parent;
import edu.njust.entity.Student;
import edu.njust.entity.Teacher;
import edu.njust.service.CourseMsgService;
import edu.njust.service.CourseService;
import edu.njust.service.NoticeService;
import edu.njust.service.ParentService;
import edu.njust.service.StudentService;
import edu.njust.service.TeacherService;
import edu.njust.utils.DateUtils;

public class ManageInforServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public ManageInforServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8"); 
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String param=request.getParameter("param");
		System.out.print("param+"+param);
		 if(param.equals("lookupstu")){
			 Integer id=Integer.parseInt(request.getParameter("id"));
			 CourseMsgService mms =new  CourseMsgService();
			 StudentService ss =new StudentService();
			 List<CourseMsg> cm = mms.getCourseMsgs1Byid(id);
			 System.out.print(cm);
			 List<Student> stu=new ArrayList<Student>(); 
			 System.out.print(id);
				for(CourseMsg cc:cm){
					
					System.out.println("cc.count"+cc.getAccount());
					System.out.println("值结果为"+ss.getStudent(cc.getAccount()));
					if(cc.getAccount()>=50000000)
				    {  Student a = ss.getStudent(cc.getAccount());
				       stu.add(a);
				      }	
				}
		     String id1 =request.getParameter("id");
		     request.getSession().setAttribute("id",id1 );	
		     request.getSession().setAttribute("stulist",stu );	
			 request.getRequestDispatcher("infor3.jsp").forward(request,response);
		 }
		else if(param.equals("sure")||param.equals("suredel")){
			Integer id=Integer.parseInt(request.getParameter("id"));
			Integer account=Integer.parseInt(request.getParameter("account"));
		if(param.equals("sure")){
			CourseService cs=new CourseService();
			CourseMsgService cmg= new CourseMsgService();
			StudentService a1 = new StudentService();
			TeacherService ts =new TeacherService();
			Student stt =a1.getStudent(account);
			Course a = cs.getCourse(id);
			CourseMsg cm =new CourseMsg(id,account);
			if(stt.getClasstime()>0){
				cmg.delCourseMsg(cm);
				Date nowDate = new Date(System.currentTimeMillis());
				SimpleDateFormat time1 = new SimpleDateFormat("yyyy年MM月dd日-HH时mm分");
				String time = time1.format(nowDate);
					CourseMsgFin cf =new CourseMsgFin(a.getType(),a.getStudentnum(),a.getTeachername(),account,time);
					cmg.addCourseMsg2(cf);
					cs.changeStatus(id);
			
				a1.haveClass(account);
				ts.haveStu(a.getTeacheracc());
			}
			else{
				NoticeService notser=new NoticeService();
				String not = "你的课次已经不足，请尽快充值！";
				Notice n1 =new Notice(account,not);
				notser.addNotice(n1);
				cmg.delCourseMsg(cm);
			}
		 }
		else{
			CourseMsgService cmg= new CourseMsgService();
			CourseMsg cm =new CourseMsg(id,account);
				cmg.delCourseMsg(cm);
				CourseService cs= new CourseService();
				cs.delbookCourse(id);
			
		}
		
		CourseMsgService mms =new  CourseMsgService();
		 StudentService ss =new StudentService();
		 List<CourseMsg> cm = mms.getCourseMsgs1Byid(id);
		 List<Student> stu=new ArrayList<Student>(); 
			for(CourseMsg cc:cm){
				if(cc.getAccount()>=50000000)
			    {  Student a = ss.getStudent(cc.getAccount());
			       stu.add(a);
			      }	
			}
	     String id1 =request.getParameter("id");
	     request.getSession().setAttribute("id",id1 );	
	     request.getSession().setAttribute("stulist",stu );	
		 request.getRequestDispatcher("infor3.jsp").forward(request,response);
		}
		
		else if(param.equals("overclass")){
			
			Integer id=Integer.parseInt(request.getParameter("id"));
			CourseService cs=new CourseService();
			CourseMsgService cmg= new CourseMsgService();
			StudentService a1 = new StudentService();
			TeacherService ts =new TeacherService();
			Course a = cs.getCourse(id);
			Integer teacheracc = a.getTeacheracc();
			ts.haveClass(teacheracc);
			CourseMsg msg =new CourseMsg(id ,teacheracc);
			cmg.delCourseMsg1byCourse(id);
			Date nowDate = new Date(System.currentTimeMillis());
			SimpleDateFormat time1 = new SimpleDateFormat("yyyy年MM月dd日-HH时mm分");
			String time = time1.format(nowDate);
		    CourseMsgFin cf =new CourseMsgFin(a.getType(),a.getStudentnum(),a.getTeachername(),teacheracc,time);
			cmg.addCourseMsg2(cf);
				cs.changeStatus(id);
		
			
			 List<Course> courseList=new ArrayList<Course>(); 
				CourseService ca =new CourseService();
				List<Course> course=ca.getCourses();
				for(Course cc:course){
					if(cc.getCoursestatus()==1)
				    courseList.add(cc);	
				}
				request.getSession().setAttribute("courselist1", courseList);
				request.getRequestDispatcher("infor1.jsp").forward(request,response);		
		}
		else if(param.equals("delcoursebyme")){
			Integer id=Integer.parseInt(request.getParameter("id"));
			StudentService stuser =new StudentService();
			CourseService  couser =new CourseService();
			CourseMsgService coumsg = new CourseMsgService();
			NoticeService notser =new NoticeService();
			List<CourseMsg> cm1=coumsg.getCourseMsgs1Byid(id);
			for(CourseMsg c:cm1){
				int acc=c.getAccount();
				String not = id+"课因老师原因取消";
				Notice n1 =new Notice(acc,not);
				notser.addNotice(n1);
			
			}
			coumsg.delCourseMsg1byCourse(id);
			couser.returnIfdel(id);
			 List<Course> courseList=new ArrayList<Course>(); 
				CourseService a =new CourseService();
				List<Course> course=a.getCourses();
				for(Course cc:course){
					if(cc.getCourseifdel()==1)
				    courseList.add(cc);	
				}
				request.getSession().setAttribute("courselist1", courseList);
				request.getRequestDispatcher("infor2.jsp").forward(request,response);
			}
		else if(param.equals("delcoursebypeople")){
			
			Integer id=Integer.parseInt(request.getParameter("id"));
			StudentService stuser =new StudentService();
			CourseService  couser =new CourseService();
			CourseMsgService coumsg = new CourseMsgService();
			NoticeService notser =new NoticeService();
			List<CourseMsg> cm1=coumsg.getCourseMsgs1Byid(id);
			for(CourseMsg c:cm1){
				int acc=c.getAccount();
				String not = id+"课因人数原因或舞室原因取消";
				Notice n1 =new Notice(acc,not);
				notser.addNotice(n1);
			
			}
			coumsg.delCourseMsg1byCourse(id);
			couser.changeStatus(id);
			List<Course> courseList=new ArrayList<Course>(); 
			CourseService ca =new CourseService();
			List<Course> course=ca.getCourses();
			for(Course cc:course){
				if(cc.getCoursestatus()==1)
			    courseList.add(cc);	
			}
			request.getSession().setAttribute("courselist1", courseList);
			request.getRequestDispatcher("infor1.jsp").forward(request,response);	
			}
       else if(param.equals("addnotice")){
			
			Integer id=Integer.parseInt(request.getParameter("id"));
			StudentService stuser =new StudentService();
			CourseService  couser =new CourseService();
			CourseMsgService coumsg = new CourseMsgService();
			NoticeService notser =new NoticeService();
			List<CourseMsg> cm1=coumsg.getCourseMsgs1Byid(id);
			for(CourseMsg c:cm1){
				int acc=c.getAccount();
				String not = id+"课因人数原因或舞室原因取消";
				Notice n1 =new Notice(acc,not);
				notser.addNotice(n1);
			
			}
			coumsg.delCourseMsg1byCourse(id);
			couser.changeStatus(id);
			List<Course> courseList=new ArrayList<Course>(); 
			CourseService ca =new CourseService();
			List<Course> course=ca.getCourses();
			for(Course cc:course){
				if(cc.getCoursestatus()==1)
			    courseList.add(cc);	
			}
			request.getSession().setAttribute("courselist1", courseList);
			request.getRequestDispatcher("infor1.jsp").forward(request,response);	
			}
       else if(param.equals("33")){
			
			
			request.getRequestDispatcher("infor4.jsp").forward(request,response);	
			}
       else if(param.equals("41")||param.equals("delNoticePar")){
    		HttpSession session=request.getSession();
			Integer account=Integer.parseInt((String)session.getAttribute("useraccount"));
			if(param.equals("delNoticePar")){
				Integer id=Integer.parseInt(request.getParameter("id"));
				NoticeService ns =new NoticeService();
				ns.delNotice(id);
			}
			NoticeService ns =new NoticeService();
			List<Notice> n1=ns.getNotices(account);
			request.getSession().setAttribute("noticelist",n1);
			request.getRequestDispatcher("Parent1.jsp").forward(request,response);
			}
       else if(param.equals("14")||param.equals("delNoticeTer")){
   		HttpSession session=request.getSession();
			Integer account=Integer.parseInt((String)session.getAttribute("useraccount"));
			if(param.equals("delNoticeTer")){
				Integer id=Integer.parseInt(request.getParameter("id"));
				NoticeService ns =new NoticeService();
				ns.delNotice(id);
			}
			NoticeService ns =new NoticeService();
			List<Notice> n1=ns.getNotices(account);
			request.getSession().setAttribute("noticelist",n1);
			request.getRequestDispatcher("Teacher4.jsp").forward(request,response);
			}
       else if(param.equals("24")||param.equals("delNoticeStu")){
			HttpSession session=request.getSession();
			Integer account=Integer.parseInt((String)session.getAttribute("useraccount"));
			if(param.equals("delNoticeStu")){
				Integer id=Integer.parseInt(request.getParameter("id"));
				NoticeService ns =new NoticeService();
				ns.delNotice(id);
			}
			NoticeService ns =new NoticeService();
			List<Notice> n1=ns.getNotices(account);
			request.getSession().setAttribute("noticelist",n1);
			request.getRequestDispatcher("Student3.jsp").forward(request,response);
			}
       else if(param.equals("delNoticeTer")){
      		HttpSession session=request.getSession();
   			Integer account=Integer.parseInt((String)session.getAttribute("useraccount"));
   			if(param.equals("delNoticeTer")){
   				Integer id=Integer.parseInt(request.getParameter("id"));
   				NoticeService ns =new NoticeService();
   				ns.delNotice(id);
   			}
   			NoticeService ns =new NoticeService();
   			List<Notice> n1=ns.getNotices(account);
   			request.getSession().setAttribute("noticelist",n1);
   			request.getRequestDispatcher("Teacher4.jsp").forward(request,response);
   			}
       else if(param.equals("addnoticebyme")){
    	    String account=request.getParameter("account");
    	    String notice =request.getParameter("notice");
    	    NoticeService ns =new NoticeService();
    	    if(notice==null||notice==""||account==null||account=="")
    	    {
    	    	request.getSession().setAttribute("param","falseinput");
    	    }
    	    else if(account.equals("1")){
    	    	StudentService stuser =new StudentService();
    	    	List<Student> stul= stuser.getStudents();
    	    	for(Student s:stul){
    	    		Integer acc = s.getAccount();
    	    		Notice n1 =new Notice(acc,notice);
    	    		ns.addNotice(n1);
    	    	}
    	    }
    	    else if(account.equals("2")){
    	    	TeacherService t =new TeacherService();
    	    	List<Teacher> tea = t.getTeachers();
    	    	for(Teacher t1:tea){
    	    		Integer acc = t1.getAccount();
    	    		Notice n1 =new Notice(acc,notice);
    	    		ns.addNotice(n1);
    	    	}
    	    }
    	    else if(account.equals("3")){
    	    	ParentService ps =new ParentService();
    	    	List<Parent> p =ps.getParents();
    	    	for(Parent p1:p){
    	    		Integer acc = p1.getAccount();
    	    		Notice n1 =new Notice(acc,notice);
    	    		ns.addNotice(n1);
    	    	}
    	    }
    	    else if(account!=null){
    	    	System.out.print(account);
    	    	Integer account1=Integer.parseInt(account);
    	    	Notice n1 =new Notice(account1,notice);
	    		ns.addNotice(n1);
    	    }
    	    
    		request.getRequestDispatcher("infor4.jsp").forward(request,response);	
       }
       else if(param.equals("27")){
    	   HttpSession session=request.getSession();
			Integer account=Integer.parseInt((String)session.getAttribute("useraccount"));
   		    StudentService stus =new StudentService();
            Student me =stus.getStudent(account);
   		    String pid =request.getParameter("pid");
   		    if(pid.equals("2"))
   		    { 
   		         stus.changeStatus1(account);
   		    }
   		    
   		    else if(pid.equals("3")){
   		    	stus.changeStatus2(account);
   		    }
 
			me.setPwd("000000");
			request.getSession().setAttribute("stu",me);
			request.getRequestDispatcher("Student5.jsp").forward(request,response);
			}

	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
