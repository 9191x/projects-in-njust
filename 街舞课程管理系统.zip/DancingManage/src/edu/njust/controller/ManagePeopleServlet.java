package edu.njust.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.njust.entity.*;
import edu.njust.service.*;

public class ManagePeopleServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public ManagePeopleServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8"); 
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		
		String param=request.getParameter("param");
		if(param==null)
			param="1";
		if(param.equals("1")||param.equals("11")||param.equals("12")||param.equals("13")){
			StudentService a=new StudentService();
			if(param.equals("11")){
			Integer account = Integer.parseInt(request.getParameter("account"));
				Student b=a.getStudent(account);
				if(b.getAcc_status()==0||b.getAcc_status()==1)
			
				{	
					a.changeStatus9(account);
					a.addClasstime1(account); }
				else if(b.getAcc_status()==2){
					a.changeStatus9(account);
					a.addClasstime2(account);
				}
			}
			else if(param.equals("12")){
				
				Integer account = Integer.parseInt(request.getParameter("account"));
				Student b=a.getStudent(account);
				if(b.getAcc_status()!=0)
				a.changeStatus9(account);
				
			}
			else if(param.equals("13")){
				Integer account = Integer.parseInt(request.getParameter("account"));
				a.delStudent(account);
			}
			StudentService c=new StudentService();
			List<Student> stu=c.getStudents();
            
		request.getSession().setAttribute("student", stu);
		
		request.getRequestDispatcher("manager.jsp").forward(request,response);
		
	  }
		
	
	     else if(param.equals("2")||param.equals("21")){
	    		TeacherService a=new TeacherService();
	    		if(param.equals("21")){
	    	      Integer account = Integer.parseInt(request.getParameter("account"));
	   	    	  a.delTeacher(account);
	    		}
				List<Teacher> tea=a.getTeachers();			
			request.getSession().setAttribute("teacher", tea);
			request.getRequestDispatcher("manager1.jsp").forward(request,response);
		  }
	     else if(param.equals("22")||param.equals("23")){
			if(param.equals("22")){
				
	    		request.getRequestDispatcher("addTeacher.jsp").forward(request,response);
	    		}
			else
			{   TeacherService a=new TeacherService();
				if(request.getParameter("t_name")!=""||request.getParameter("t_pwd")!=""||request.getParameter("t_phone")!=""){
				String name=request.getParameter("t_name");
				String pwd=request.getParameter("t_pwd");
				String phone=request.getParameter("t_phone");
				Teacher t=new Teacher(name,pwd,phone);
				
				a.addTeacher(t);}
				List<Teacher> tea=a.getTeachers();			
				request.getSession().setAttribute("teacher", tea);
				request.getRequestDispatcher("manager1.jsp").forward(request,response);
				
			}
		}
	     else if(param.equals("3")||param.equals("31")){
	    		ParentService a=new ParentService();
	    		if(param.equals("31")){
	    			Integer account = Integer.parseInt(request.getParameter("account"));
		    	      System.out.print("进入21");
		   	    	  a.delParent(account);
	    		}
				List<Parent> par=a.getParents();			
			request.getSession().setAttribute("parent", par);
			System.out.print(par.toString());
			request.getRequestDispatcher("manager2.jsp").forward(request,response);
			System.out.print("进入3");
		  }
	     else if(param.equals("4")||param.equals("41")){
	    		InformerService a=new InformerService();
	    		if(param.equals("41")){
	    	      Integer account = Integer.parseInt(request.getParameter("account"));
	   	    	  a.delInformer(account);
	    		}
				List<Informer> inf=a.getInformers();			
			request.getSession().setAttribute("informer", inf);
			request.getRequestDispatcher("manager3.jsp").forward(request,response);
		  }
	     else if(param.equals("42")||param.equals("43")){
			if(param.equals("42")){
	    		request.getRequestDispatcher("addInformer.jsp").forward(request,response);
	    		}
			else
			{   InformerService a=new InformerService();
				if(request.getParameter("i_name")!=""||request.getParameter("i_pwd")!=""||request.getParameter("i_phone")!=""){
				String name=request.getParameter("i_name");
				String pwd=request.getParameter("i_pwd");
				String phone=request.getParameter("i_phone");
				Informer i=new Informer(name,pwd,phone);
				
				a.addInformer(i);}
				List<Informer> inf=a.getInformers();			
				request.getSession().setAttribute("informer", inf);
				request.getRequestDispatcher("manager3.jsp").forward(request,response);
			
			}
		}
		System.out.print("跳出");
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8"); 
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String param=request.getParameter("param");
		if(param.equals("22")||param.equals("23")){
			if(param.equals("22")){
	    		request.getRequestDispatcher("addTeacher.jsp").forward(request,response);
	    		}
			else
			{
				String name=request.getParameter("t_name");
				String pwd=request.getParameter("t_pwd");
				String phone=request.getParameter("t_phone");
				Teacher t=new Teacher(name,pwd,phone);
				TeacherService a=new TeacherService();
				a.addTeacher(t);
				request.getRequestDispatcher("manager1.jsp").forward(request,response);
				
			}
		}
		
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
