/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 50017
 Source Host           : localhost:3306
 Source Schema         : dancemanagement

 Target Server Type    : MySQL
 Target Server Version : 50017
 File Encoding         : 65001

 Date: 07/10/2021 11:21:01
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for administrators
-- ----------------------------
DROP TABLE IF EXISTS `administrators`;
CREATE TABLE `administrators`  (
  `account` int(5) NULL DEFAULT NULL,
  `pwd` varchar(20) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = gb2312 COLLATE = gb2312_chinese_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of administrators
-- ----------------------------
INSERT INTO `administrators` VALUES (11111, 'lhxxsp');

-- ----------------------------
-- Table structure for course
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course`  (
  `id` int(10) NOT NULL DEFAULT 0,
  `type` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `studentnum` int(11) NULL DEFAULT 0,
  `teacheracc` int(11) NULL DEFAULT NULL,
  `teachername` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `courseifdel` int(11) NULL DEFAULT 0,
  `coursestatus` int(11) NULL DEFAULT 1,
  PRIMARY KEY USING BTREE (`id`)
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO `course` VALUES (131, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (132, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (133, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (141, 'jazz', 2, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (142, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (143, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (231, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (232, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (233, 'hiphop', 2, 40000000, 'YG', 0, 1);
INSERT INTO `course` VALUES (241, 'jazz', 1, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (242, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (243, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (331, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (332, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (333, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (341, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (342, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (343, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (431, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (432, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (433, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (441, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (442, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (443, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (531, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (532, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (533, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (541, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (542, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (543, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (611, 'hiphop', 2, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (612, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (613, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (621, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (622, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (623, 'jazz', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (631, 'Tango', 1, 40000000, 'YG', 0, 1);
INSERT INTO `course` VALUES (632, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (633, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (641, 'jazz', 0, 40000000, 'gj', 0, 0);
INSERT INTO `course` VALUES (642, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (643, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (711, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (712, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (713, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (721, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (722, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (723, 'Latin', 1, 40000000, 'YG', 0, 1);
INSERT INTO `course` VALUES (731, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (732, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (733, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (741, 'hiphop', 1, 40000000, 'YG', 0, 1);
INSERT INTO `course` VALUES (742, 'hiphop', 0, 40000000, 'YG', 0, 0);
INSERT INTO `course` VALUES (743, 'hiphop', 0, 40000000, 'YG', 0, 0);

-- ----------------------------
-- Table structure for coursemsg1
-- ----------------------------
DROP TABLE IF EXISTS `coursemsg1`;
CREATE TABLE `coursemsg1`  (
  `account` int(8) NULL DEFAULT NULL,
  `courseid` int(11) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = gb2312 COLLATE = gb2312_chinese_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of coursemsg1
-- ----------------------------
INSERT INTO `coursemsg1` VALUES (40000000, 141);
INSERT INTO `coursemsg1` VALUES (40000000, 233);
INSERT INTO `coursemsg1` VALUES (20000000, 141);
INSERT INTO `coursemsg1` VALUES (20000000, 233);
INSERT INTO `coursemsg1` VALUES (50000000, 233);
INSERT INTO `coursemsg1` VALUES (40000000, 741);
INSERT INTO `coursemsg1` VALUES (40000000, 723);
INSERT INTO `coursemsg1` VALUES (40000000, 631);
INSERT INTO `coursemsg1` VALUES (50000000, 631);
INSERT INTO `coursemsg1` VALUES (50000000, 723);
INSERT INTO `coursemsg1` VALUES (50000000, 741);

-- ----------------------------
-- Table structure for coursemsgfin
-- ----------------------------
DROP TABLE IF EXISTS `coursemsgfin`;
CREATE TABLE `coursemsgfin`  (
  `type` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `studentnum` int(11) NULL DEFAULT NULL,
  `teachername` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `account` int(8) NULL DEFAULT NULL,
  `time` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of coursemsgfin
-- ----------------------------
INSERT INTO `coursemsgfin` VALUES ('jazz', 1, 'YG', 40000000, '2021年10月07日-00时47分');
INSERT INTO `coursemsgfin` VALUES ('jazz', 2, 'YG', 50000000, '2021年10月07日-10时55分');
INSERT INTO `coursemsgfin` VALUES ('jazz', 1, 'YG', 40000000, '2021年10月07日-10时55分');

-- ----------------------------
-- Table structure for informer
-- ----------------------------
DROP TABLE IF EXISTS `informer`;
CREATE TABLE `informer`  (
  `account` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pwd` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY USING BTREE (`account`)
) ENGINE = InnoDB AUTO_INCREMENT = 20000001 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of informer
-- ----------------------------
INSERT INTO `informer` VALUES (20000000, '小张', '111111', '15592440742');

-- ----------------------------
-- Table structure for msg
-- ----------------------------
DROP TABLE IF EXISTS `msg`;
CREATE TABLE `msg`  (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `context` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY USING BTREE (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of msg
-- ----------------------------
INSERT INTO `msg` VALUES (1, '张三', '街舞好累');

-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice`  (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `account` int(11) NULL DEFAULT NULL,
  `noticess` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY USING BTREE (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES (1, 40000000, '623课因人数原因或舞室原因取消');
INSERT INTO `notice` VALUES (2, 50000000, '舞室装修，所有学生今天停课');
INSERT INTO `notice` VALUES (3, 40000000, '舞室装修，所有教师今天不上课。');
INSERT INTO `notice` VALUES (4, 80000000, '各位家长好，由于舞室装修，故学生今日不上课。');
INSERT INTO `notice` VALUES (5, 50000000, '今天不上课哦');
INSERT INTO `notice` VALUES (6, 40000000, '633课因人数原因或舞室原因取消');
INSERT INTO `notice` VALUES (7, 40000000, '611课因人数原因或舞室原因取消');
INSERT INTO `notice` VALUES (8, 20000000, '611课因人数原因或舞室原因取消');
INSERT INTO `notice` VALUES (9, 50000000, '611课因人数原因或舞室原因取消');

-- ----------------------------
-- Table structure for parents
-- ----------------------------
DROP TABLE IF EXISTS `parents`;
CREATE TABLE `parents`  (
  `account` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pwd` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `chindaccount` int(8) NULL DEFAULT NULL,
  `chindname` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `email` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY USING BTREE (`account`)
) ENGINE = InnoDB AUTO_INCREMENT = 80000001 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of parents
-- ----------------------------
INSERT INTO `parents` VALUES (80000000, '张四', '123456', 50000000, '张三', '177132222@qq.com', '187059999');

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student`  (
  `account` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pwd` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `brithday` date NULL DEFAULT NULL,
  `email` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `accstatus` int(11) NULL DEFAULT 0,
  `classtime` int(11) NULL DEFAULT 0,
  `parentsnum` int(11) NULL DEFAULT 3,
  PRIMARY KEY USING BTREE (`account`)
) ENGINE = InnoDB AUTO_INCREMENT = 50000001 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES (50000000, '张三', '123456', '2001-05-21', '1771327637@qq.com', '18705180913', 9, 9, 2);

-- ----------------------------
-- Table structure for teacher
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher`  (
  `account` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pwd` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `teachstunum` int(11) NULL DEFAULT 0,
  `teachcousenum` int(11) NULL DEFAULT 0,
  PRIMARY KEY USING BTREE (`account`)
) ENGINE = InnoDB AUTO_INCREMENT = 40000001 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of teacher
-- ----------------------------
INSERT INTO `teacher` VALUES (40000000, 'YG', '111111', '16687426756', 1, 1);

SET FOREIGN_KEY_CHECKS = 1;
