#include <iostream>
#include <fstream>
#include <stack>
#include <cstring>
#include<iomanip>
#include<vector>
using namespace std;

char buffer[300];
bool bufferFlag[300];		//���buffer[]������
char Grammar[300][300];		//���ķ�
int gramLength[300];		//�ķ��ĳ���
int gramNumber=0;		//�ķ���
//�ս��
char Terminal[300];
int tLength=0;
//���ս��
char nonTerminal[300];
int nontLength=0;
//first��
bool first[300][300];
//��Ŀ��
struct project {
	int number;
	int now;
	char searchO;
};
project projectSet[300][300];
int proSetLength[300];
int count=0;
//������
struct action {
	char c;
	int nState;
};
action anaTable[300][300];
int aTableLength[300];
//ת����������Ŀ��ת��
struct table {
	int start;
	int next;
	char c;
};
table cTable[300];
int cTableLength=0;
//����ջ���ڷ���
stack<int> Sstack;
stack<char> stackFlag;
int counter=0;
ofstream anaProcessOut;//��¼��������

void readGrammar() {
	ifstream grammarRead;
	grammarRead.open("�﷨����_�ķ�.txt");
	char temp,input;
	int i,j=0;
	Grammar[0][0]='S';
	gramLength[0]=2;
	grammarRead>>gramNumber;
	for(int i=1; i<=gramNumber; i++) {
		int j=0;
		grammarRead>>input;
		grammarRead>>temp>>temp;
		while(input!='$') {
			Grammar[i][j++]=input;
			bufferFlag[input]=true;
			grammarRead>>input;
		}
		gramLength[i]=j;
	}
	Grammar[0][1]=Grammar[1][0];
	//д���ս���ͷ��ս��
	for(int i=0; i<64; i++) {
		if(bufferFlag[i]) {
			Terminal[tLength++]=i;
		}
	}
	for(int i=65; i<91; i++) {
		if(bufferFlag[i]) {
			nonTerminal[nontLength++]=i;
		}
	}
	for(int i=91; i<128; i++) {
		if(bufferFlag[i]) {
			Terminal[tLength++]=i;
		}
	}
	grammarRead.close();
}
void getFirst() {
	bool flag1=true;//����Ƿ��������
	int temp1,temp2;
	bool flag2;
	while(flag1) {
		flag1=false;
		for(int i=1; i<=gramNumber; i++) {
			temp1=1;
			flag2=true;
			while(flag2 && temp1<gramLength[i]) {
				flag2=false;
				if(Grammar[i][temp1]>='A' && Grammar[i][temp1]<='Z') {
					for(temp2=0; temp2<=63; temp2++) {
						if(first[Grammar[i][temp1]-'A'][temp2]==true && !first[Grammar[i][0]-'A'][temp2]) {
							first[Grammar[i][0]-'A'][temp2]=true;
							flag1=true;
						}
					}
					if(first[Grammar[i][temp1]-'A'][64]==true) {//@��ʾ ��
						flag2=true;
						temp1++;
					}
					for(temp2=91; temp2<128; temp2++) {
						if(first[Grammar[i][temp1]-'A'][temp2]==true && first[Grammar[i][0]-'A'][temp2]==false) {
							flag1=true;
							first[Grammar[i][0]-'A'][temp2]=true;
						}
					}
				} else if(first[Grammar[i][0]-'A'][Grammar[i][temp1]]==false) {
					flag1=true;
					first[Grammar[i][0]-'A'][Grammar[i][temp1] ]=true;
				}
			}
			if(gramLength[i]==temp1) {
				first[Grammar[i][0]-'A'][26]=true;
			}
		}
	}
}
void getFSymbol(project temp) {
	counter=0;
	bool flag=true;
	int temp2=temp.now;
	int i;
	while(flag==true) {
		flag=false;
		if(temp2+1>=gramLength[temp.number]) {
			buffer[counter++]=temp.searchO;
			break;
		} else if(Grammar[temp.number][temp2+1]<'A' || Grammar[temp.number][temp2+1]>'Z') {
			buffer[counter++]=Grammar[temp.number][temp2+1];
			break;
		} else if(Grammar[temp.number][temp2+1]>='A' && Grammar[temp.number][temp2+1]<='Z') {
			for(i=0; i<64; i++) {
				if(first[Grammar[temp.number][temp2+1]-'A'][i]==true)
					buffer[counter++]=i;
			}
			for(i=91; i<128; i++) {
				if(first[Grammar[temp.number][temp2+1]-'A'][i]==true) {
					buffer[counter++] = i;
				}
			}
			if(first[Grammar[temp.number][temp2+1]-'A'][64]==true) {
				temp2++;
				flag=true;
			}
		}
	}
}
//��Ŀ��Ԫ���Ƿ��Ѵ���
bool isExist1(project temp,int a) {
	for(int i=0; i<proSetLength[a]; i++) {
		if(projectSet[a][i].number==temp.number && projectSet[a][i].now==temp.now && projectSet[a][i].searchO==temp.searchO) {
			return true;
		}
	}
	return false;
}
//�õ���Ŀ����
void closure(int s) {
	project temp;
	for(int i=0; i<proSetLength[s]; i++) {
		if(Grammar[projectSet[s][i].number][projectSet[s][i].now]>='A'
		        && Grammar[projectSet[s][i].number][projectSet[s][i].now]<='Z') {
			for(int j=0; j<300; j++) {
				counter=0;
				if(Grammar[j][0]==Grammar[projectSet[s][i].number][projectSet[s][i].now]) {
					getFSymbol(projectSet[s][i]);
					for(int k=0; k<counter; k++) {
						temp.number=j;
						temp.now=1;
						temp.searchO=buffer[k];
						if(isExist1(temp,s)==false) {
							projectSet[s][proSetLength[s]++]=temp;
						}
					}
				}
			}
		}
	}
}
//��ǰ��Ŀ���Ƿ����
int isExist2() {
	int temp=0;//��¼������
	for(int i=0; i<count; i++) {
		temp=0;
		if(proSetLength[count]==proSetLength[i]) {
			for(int j=0; j<proSetLength[count]; j++) {
				for(int k=0; k<proSetLength[i]; k++) {
					if(projectSet[i][k].number==projectSet[count][j].number&& projectSet[i][k].now==projectSet[count][j].now
					        && projectSet[i][k].searchO==projectSet[count][j].searchO) {
						temp++;
						break;
					}
				}
			}
		}
		if(temp==proSetLength[count]) {
			return i;
		}
	}
	return 0;
}
void getProjectSet() {
	ofstream projectsOut;
	projectsOut.open("��Ŀ��.txt");
	projectSet[0][0].number=0;
	projectSet[0][0].now=1;
	projectSet[0][0].searchO='#';
	proSetLength[0]=1;
	closure(0);
	project tBuffer[50];
	int tBufCount=0;
	project tempPro;
	int i,j,k;
	int nextState1;
	projectsOut<<"I0:"<<endl;
	for(i=0; i<proSetLength[0]; i++) {
		projectsOut<<Grammar[projectSet[0][i].number][0]<<"->"<<Grammar[projectSet[0][i].number]+1<<" , "<<projectSet[0][i].now<<" , "<<projectSet[0][i].searchO<<endl;
	}
	projectsOut<<endl;
	int index;
	int m,n;
	for(index=0; index<count+1; index++) {
		for(j=0; j<tLength; j++) {
			tBufCount=0;
			for(m=0; m<proSetLength[index]; m++) {
				if(projectSet[index][m].now<gramLength[projectSet[index][m].number]
				        && Grammar[projectSet[index][m].number][projectSet[index][m].now]==Terminal[j]) {
					tempPro.number=projectSet[index][m].number;
					tempPro.searchO=projectSet[index][m].searchO;
					tempPro.now=projectSet[index][m].now+1;
					tBuffer[tBufCount++]=tempPro;
				}
			}
			if(tBufCount!= 0) {//�����µ���Ŀ��
				count++;
				for(n=0; n<tBufCount; n++) {
					projectSet[count][proSetLength[count]++]=tBuffer[n];
				}
				closure(count);
				nextState1=isExist2();//�����Ŀ���Ƿ��ظ�
				if(nextState1!=0) {//�ظ�����ת�������е��Ǹ���Ŀ����
					proSetLength[count--]=0;
					cTable[cTableLength].start=index;
					cTable[cTableLength].next=nextState1;
					cTable[cTableLength++].c=Terminal[j];
				} else {
					projectsOut<<"I"<<count<<":"<<endl;
					for(i=0; i<proSetLength[count]; i++) {
						projectsOut<<Grammar[projectSet[count][i].number][0]<<"->"<<Grammar[projectSet[count][i].number]+1<<" , "<<projectSet[count][i].now<<" , "<<projectSet[count][i].searchO<<endl;
					}
					projectsOut<<endl;
					cTable[cTableLength].start=index;
					cTable[cTableLength].next=count;
					cTable[cTableLength++].c=Terminal[j];
				}
			}
		}
		for(j=0; j<nontLength; j++) {
			tBufCount = 0;
			for(m=0; m<proSetLength[index]; m++) {
				if(projectSet[index][m].now<gramLength[projectSet[index][m].number]
				        && Grammar[projectSet[index][m].number][projectSet[index][m].now]==nonTerminal[j]) {
					tempPro.number=projectSet[index][m].number;
					tempPro.searchO=projectSet[index][m].searchO;
					tempPro.now=projectSet[index][m].now+1;
					tBuffer[tBufCount++]=tempPro;
				}
			}
			if(tBufCount!=0) {
				++count;
				for(n=0; n<tBufCount; n++) {
					projectSet[count][proSetLength[count]++]=tBuffer[n];
				}
				closure(count);
				nextState1=isExist2();
				if(nextState1!=0) {
					proSetLength[count--]=0;
					cTable[cTableLength].start=index;
					cTable[cTableLength].next=nextState1;
					cTable[cTableLength++].c=nonTerminal[j];
				} else {
					projectsOut<<"I"<<count<<":"<<endl;
					for(i=0; i<proSetLength[count]; i++) {
						projectsOut<<Grammar[projectSet[count][i].number][0]<<"->"<<Grammar[projectSet[count][i].number]+1<<" , "<<projectSet[count][i].now<<" , "<<projectSet[count][i].searchO<<endl;
					}
					projectsOut<<endl;
					cTable[cTableLength].start=index;
					cTable[cTableLength].next=count;
					cTable[cTableLength++].c=nonTerminal[j];
				}
			}
		}
	}
	projectsOut.close();
}
void getAnaTable() {
	ofstream anaTableOut;
	anaTableOut.open("������.txt");
	int t1,t2,t3;
	char temp;
	for(int i=0; i<300; i++) {
		aTableLength[i]=0;
	}
	for(int i=0; i<=count; i++) {
		for(int j=0; j<proSetLength[i]; j++) {
			if(projectSet[i][j].now==gramLength[projectSet[i][j].number] || (projectSet[i][j].now==1
			        && gramLength[projectSet[i][j].number]==2 && Grammar[projectSet[i][j].number][1]=='@')) {
				anaTable[i][aTableLength[i]].c=projectSet[i][j].searchO;
				anaTable[i][aTableLength[i]++].nState=projectSet[i][j].number*(-1);
			}
		}
	}
	for(int i=0; i<cTableLength; i++) {
		t1=cTable[i].start;
		t2=cTable[i].next;
		temp=cTable[i].c;
		anaTable[t1][aTableLength[t1]].c=temp;
		anaTable[t1][aTableLength[t1]++].nState=t2;
	}
	for(int i = 0; i <= count; i++) {
		for(int j = 0; j < aTableLength[i]; j++) {
			temp=anaTable[i][j].c;
			t3=anaTable[i][j].nState;
			anaTableOut << "(" << i << "," << temp << "," << t3 << ")" << endl;
		}
	}
	anaTableOut.close();
}
void intoStack(int s) {
	stack<int> a;
	stack<char> c;
	if(s==1) {
		while(Sstack.empty()==false) {
			a.push(Sstack.top());
			Sstack.pop();
		}
		while(a.empty()==false) {
			anaProcessOut<<a.top()<<',';
			Sstack.push(a.top());
			a.pop();
		}
		anaProcessOut<<'~';
	}
	if(s==2) {
		while(stackFlag.empty()==false) {
			c.push(stackFlag.top());
			stackFlag.pop();
		}
		while(c.empty()==false) {
			anaProcessOut<<c.top()<<',';
			stackFlag.push(c.top());
			c.pop();
		}
		anaProcessOut<<'~';
	}
}
void analyse() {
	ifstream outputRead;
	outputRead.open("output.txt");
	counter = 0;
	while(true) {
		if(outputRead>>buffer[counter] && buffer[counter++] != '#') {
			continue;
		} else break;
	}
	int tstate = 0;
	int bIndex = 0;
	bool flag1=false;
	bool flag2 = false;
	char input;
	input=buffer[0];
	Sstack.push(0);
	stackFlag.push('#');
	anaProcessOut<<"StateStack"<<'~'<<"SymbolStack"<<'~'<<"InputString"<<'~'<<"ACTION"<<'~'<<"GOTO"<<'~'<<endl;
	int temp1,temp2;
	int temp;
	while(flag2 == false && flag1 == false) {
		tstate = Sstack.top();
		intoStack(1);
		intoStack(2);
		int temp3=0;
		for(int i=bIndex; i<counter; i++) {
			anaProcessOut<<buffer[i];
			temp3++;
		}
		anaProcessOut<<'~';
		flag1 =  true;
		for(int i= 0; i < aTableLength[tstate]; i++) {
			if(anaTable[tstate][i].c ==input) {
				flag1 = false;
				if(anaTable[tstate][i].nState == 0) {
					anaProcessOut << "YES" <<'~'<< endl;
					cout<<"YES"<<endl;
					flag2 = true;
					break;
				} else if(anaTable[tstate][i].nState > 0) {
					anaProcessOut<<'S'<<anaTable[tstate][i].nState<<endl;
					Sstack.push(anaTable[tstate][i].nState);
					stackFlag.push(anaTable[tstate][i].c);
					bIndex++;
					input=buffer[bIndex];
					break;
				} else if(anaTable[tstate][i].nState < 0) {
					temp1 = anaTable[tstate][i].nState*(-1);
					anaProcessOut<<'r'<<temp1<<'~';
					temp2=gramLength[temp1]-1;
					if(Grammar[temp1][1]=='@') {
						temp2--;
					}
					for(int k = 0; k < temp2; k++) {
						Sstack.pop();
						stackFlag.pop();
					}
					stackFlag.push(Grammar[temp1][0]);
					temp=Sstack.top();
					for(int m=0; m<aTableLength[temp]; m++) {
						if(anaTable[temp][m].c==Grammar[temp1][0]) {
							Sstack.push(anaTable[temp][m].nState);
							anaProcessOut<<anaTable[temp][m].nState<<'~'<<endl;
						}
					}
					break;
				}
			}
		}
	}
	if(!flag2) {
		cout << "NO" << endl;
		cout<<"δ�ҵ���";
		for(int i=0; i<aTableLength[tstate]; i++) {
			cout<<anaTable[tstate][i].c<<" "<<endl;
		}
		cout<<endl;
	}
	outputRead.close();
}
//�Ƿ��Ƿ��ս��
bool isExist3(char a) {
	for(int i=0; i<nontLength; i++) {
		if(nonTerminal[i]==a) {
			return true;
		}
	}
	return false;
}
void LR1() {
	readGrammar();
	getFirst();
	//��first��д���ļ� "first��.txt"
	ofstream firstSetOut;//���first��
	firstSetOut.open("first��.txt");
	for(int i=0; i<26; i++) {
		char c=char(i+'A');
		if(isExist3(c)) {
			firstSetOut<<"first("<<c<<")={";
			for(int j=0; j<128; j++) {
				if(first[i][j]==true) {
					firstSetOut<<char(j)<<",";
				}
			}
			firstSetOut<<"}"<<endl;
		}
	}
	firstSetOut.close();
	getProjectSet();
	getAnaTable();
	analyse();
}
bool isChar(char c) {
	bool flag=false;
	if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c=='+')||(c=='-')||(c=='*')||(c=='/')||(c=='#')||
	        (c=='{')||(c=='}')||(c=='(')||(c==')')||(c==',')||(c==';')||(c=='<')||(c=='>')) {
		flag=true;
	}
	return flag;
}
int getLength(char a[]) {
	int count=0;
	for(int i=0; i<256; i++) {
		if(isChar(a[i])==true)
			count++;
		else continue;
	}
	return count;
}
void format() {
	ifstream read1;
	read1.open("����.txt");
	ofstream ana;
	ana.open("��������.txt");
	string str;
	while (getline(read1,str)) {
		string str2;
		int count1=0;
		for(int i=0; i<str.length(); i++) {
			if(str[i]!='~') {
				str2.push_back(str[i]);
				count1++;
			} else {
				ana<<str2;
				str2.clear();
				for(int i=0; i<(70-count1); i++)
					ana<<" ";
				count1=0;
			}
		}
		ana<<endl;
	}

	read1.close();
	ana.close();
}
int main() {
	anaProcessOut.open("����.txt");
	for(int i=0; i<300; i++) {
		bufferFlag[i]=false;
	}
	for(int i=0; i<300; i++) {
		proSetLength[i]=0;
	}
	for(int i=0; i<300; i++) {
		for(int j=0; j<300; j++) {
			first[i][j]=false;
		}
	}
	counter=0;
	LR1();
	anaProcessOut.close();
	format();
	system("pause");
	return 0;
}

