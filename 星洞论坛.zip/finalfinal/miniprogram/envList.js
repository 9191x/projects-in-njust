const envList = [{"envId":"cloud1-4gqqyar07d66c352","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}