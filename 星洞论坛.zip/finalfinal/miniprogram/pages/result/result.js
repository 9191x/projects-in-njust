// pages/post/post.js
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    content: "",
    content2: '',
    words: "唱歌",
    userid: 0,
    before:"",
    posts: [],
    user: {
      username: 'Young',
      birthday: '2001-10-06',
      job: '学生',
      hometown: '安徽',
      phone: '138-9999-9999',
      gender: '男',
      portrait: '/images/user/user_1/portrait.jpg',
      url: '../data/data'
    },
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // this.setData({ 
    //   userid: options.userid
    // })
    // console.log(this.data.userid)
   
    this.setData({
      content: options.content,
      before:options.before
      //undefine
    })
    this.setData({
      content2: options.content2
      //undefine
    })
    console.log("content:", this.data.content)
    console.log("content2:", this.data.content2)
    console.log("33333", this.data.content)
    if (this.data.content != null && this.data.content2 != null) {
      const _ = db.command
      var that = this
      db.collection('forumPost').where({
        labelArr: _.all([that.data.content2])
      }).get()
        .then(res => {
          that.setData({
            posts: res.data
          })
        })
    }
    else if (this.data.content == null && this.data.content2 != null) {
      const _ = db.command
      var that = this
      db.collection('forumPost').where({
        labelArr: _.all([that.data.content2])
      }).get()
        .then(res => {
          that.setData({
            posts: res.data
          })
        })
    }
    else if (this.data.content != null && this.data.content2 == null) {
      if (this.data.content == '') {
        // wx.showLoading({
        //   title: '加载中',
        // })

        // setTimeout(function () {
        //   wx.hideLoading()
        // }, 2000)
        wx.navigateTo({
          url: '../search/search',
        })
        wx.showToast({
          title: '未查询到相关话题！',
          icon: 'success',
          duration: 2000
        })

      }
      else {
        wx.cloud.init()
        var that = this
        console.log(that.data.content, "8888888888888888")
        const _ = db.command
        db.collection('forumPost')
          .where(_.or([{
            header: db.RegExp({
              regexp: '.*' + that.data.content,
              options: 'i',
            })
          }
          ]))
          .limit(20)
          .get({
            success: function (res) {
              console.log(res.data);
              that.setData({
                posts: res.data
              })
              console.log("跳转到搜索后显示的页面")
              console.log("3333333333", posts)
            }
          })
      }

    }
    else {

      wx.navigateTo({
        url: '../search/search',
      })
      wx.showToast({
        title: '未查询到相关话题！',
        icon: 'success',
        duration: 2000
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    if(this.data.before=="search"){
      wx.navigateTo({
       url : '../search/search'
      })
    }

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  search: function (e) {
    wx.redirectTo({
      url: '../result/result?content=' + e.detail.value.words,
    })
  }
})