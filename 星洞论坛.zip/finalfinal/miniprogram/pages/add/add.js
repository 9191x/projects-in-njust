var util =require('../../utils/util.js')
const db = wx.cloud.database()
var app = getApp()
Page({
  data: {
    showView:true,
    imgArr:[],
    pic:"",
    labelArr:[],
    inputValue:"",
    showModal: false,
    focusInput: false,
    height: '',
    isInput: false,
    value:'',
    header:'',
    content:'',
    user:"",
    temp:[
      {
        name:"科学",
        id:0,
        selected:false
      },
      {
        name:"校园",
        id:1,
        selected:false
      },
      {
        name:"体育",
        id:2,
        selected:false
      },
      {
        name:"娱乐",
        id:3,
        selected:false
      },
      {
        name:"健康",
        id:4,
        selected:false
      },
      {
        name:"动漫",
        id:5,
        selected:false
      },
      {
        name:"时尚",
        id:6,
        selected:false
      },
      {
        name:"心理",
        id:7,
        selected:false
      },
      {
        name:"影视",
        id:8,
        selected:false
      },
      {
        name:"音乐",
        id:9,
        selected:false
      },
      {
        name:"法律",
        id:10,
        selected:false
      },
      {
        name:"宠物",
        id:11,
        selected:false
      },
    ],
    obtnArry:[
      {
        name:"科学",
        id:0,
        selected:false
      },
      {
        name:"校园",
        id:1,
        selected:false
      },
      {
        name:"体育",
        id:2,
        selected:false
      },
      {
        name:"娱乐",
        id:3,
        selected:false
      },
      {
        name:"健康",
        id:4,
        selected:false
      },
      {
        name:"动漫",
        id:5,
        selected:false
      },
      {
        name:"时尚",
        id:6,
        selected:false
      },
      {
        name:"心理",
        id:7,
        selected:false
      },
      {
        name:"影视",
        id:8,
        selected:false
      },
      {
        name:"音乐",
        id:9,
        selected:false
      },
      {
        name:"法律",
        id:10,
        selected:false
      },
      {
        name:"宠物",
        id:11,
        selected:false
      },
    ]
  },
//添加图片
  addImg:function(){
      var that = this;
      var imgArr = this.data.imgArr;
      wx.chooseImage({
        count: 1 - imgArr.length, //最多可以选择的图片张数,默认1
        success: function(res) {
          var imgsrc = res.tempFilePaths;
          imgArr = imgsrc;
          that.setData({
            imgArr: imgArr,
            showView:(!that.data.showView)
          })
          that.uploadimg();
        }
      })
      
      
  },
  //上传图片
 
  uploadimg:function(){
      var that=this,imgArr=this.data.imgArr;
      this.uploading({
          url:'',
          path:imgArr,
          //imgpic:[]
      })   
  },
  uploading:function(data){
      var that=this,
          i=data.i?data.i:0,
          success=data.success?data.succcess:0,
          fail=data.fail?data.fail:0;
      var imgpic=data.imgpic;
      wx.cloud.uploadFile({
        cloudPath:Date.now()+".jpg",
        filePath:that.data.imgArr[0]
    }).then(res=>{
        that.setData({
          pic:res.fileID
        })
    })
  },
  home:function(){
    wx.switchTab({
      url: '/pages/index/index',
    })
  },
  formsubmit:function(e){
    var postTime = util.formatTime(new Date());
    console.log('323232',postTime)
    var data1 = e.detail.value
    console.log('header',data1.header)
    console.log('content',data1.content)
    if(data1.header==''){
      wx.showToast({
        title: '请输入完整标题',
        icon:'error'
      })
    }
    else if(data1.content==''){
      wx.showToast({
        title: '请输入问题简介',
        icon:'error'
      })
    }
    else{
      db.collection("forumPost").add({
        data: {
          postTime:postTime,
          anuthorID:app.globalData.user._id,
          anuthorName:app.globalData.user.username,
          anuthorPic:app.globalData.user.userPic,
          header:data1.header,
          content:data1.content,
          goodNum:0,
          remarkNum:0,
          restoreNum:0,
          pic:this.data.pic,
          labelArr:this.data.labelArr
        },
        success: res => {
          console.log(2222222,this.data.imgArr)
          console.log(3434343434343,this.data.labelArr)
        }
      })
      this.setData({
        header:'',
        content:'',
        imgArr:'',
        labelArr: [],
        obtnArry:this.data.temp,
        showView:true
      })
      
      
      wx.switchTab({
        url: '/pages/index/index',
      })
      wx.showToast({
        title: '添加成功',
        icon:'success'
      })
      this.onLoad()
      this.onReady()
    }
  },
  inputFocus(e) {
    console.log(e, '键盘弹起')
    this.setData({
      height: e.detail.height,
      isInput: true
    })
  },
  inputBlur() {
    console.log('键盘收起')
    this.setData({
      isInput: false
    })
  },
 
  focusButn: function () {
    this.setData({
      focusInput: true,
      isInput: true
    })
  },
  bindValue(e){
    this.setData({
      inputValue: e.detail.value
    })
  },
  onInputValue(){
    this.data.labelArr.push(this.data.inputValue);//实质是添加lists数组内容，使for循环多一次
    console.log(this.data.inputValue)

    this.onLoad()
    this.onReady()
  },
  onLoad: function (options) {
    getApp().setWatcher(this); // 设置监听器

    this.setData({
        user:app.globalData.user,
        header:this.data.header,
        content:this.data.content,
        showView:this.data.showView
    })
  },
  watch:{
    labelArr:function(newValue){
      console.log(newValue); // name改变时，调用该方法输出新值。
    },
    user:function(newValue){
      console.log(newValue); 
    }
  },
  
  dealTap:function(e){  
    let string = "obtnArry[" + e.target.dataset.index + "].selected";
    // const checkedicon = "obtnArry[" + e.target.dataset.index + "].selected"; 
    console.log(!this.data.obtnArry[e.target.dataset.index].selected);
    this.setData({
      [string]: !this.data.obtnArry[e.target.dataset.index].selected
    })
    let detailValue = this.data.obtnArry.filter(it => it.selected).map(it => it.name)
    this.setData({
      label: detailValue
    })
    this.data.labelArr=this.data.label
    // console.log(this.data.labelArr) 
    this.setData({
      labelArr:this.data.labelArr
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
  
})