const db = wx.cloud.database();
var app = getApp();
const _ = db.command;
Page({
  data: {
    return:"",
    forumPost1:"",
    forumPostID:"",
    remark:"",
    flag: '',
    flag2: '',
  },

  getData() {
    db.collection("forumPost").doc(this.data.forumPostID)
      .get({
        success: res => {
          console.log("查询帖子成功   ", res.data)
          this.setData({
            forumPost1: res.data
          })
        }
      })
    db.collection("remark")
      .where({
        forumPostID: this.data.forumPostID
      })
      .orderBy('postDate', 'asc')
      .get({
        success: res => {
          console.log("查询评论：  ", res.data)
          this.setData({
            remark: res.data
          })
        }
      })
  },

  good: function () {
    var that=this
    db.collection('good').where({
      userid: app.globalData.user._id,
      postid: this.data.forumPostID
    }).get({
      success: res => {
        if (res.data[0] == null) {
          console.log("jinlaile")
          db.collection('good').add({
            data: {
              userid: app.globalData.user._id,
              isgood: true,
              postid: this.data.forumPost1._id
            },
            success: res => {

              db.collection("forumPost").where({
                _id: this.data.forumPostID
              }).update({
                data: {
                    goodNum:_.inc(1)
                },
                success: res=> {
                }
              })
              db.collection("forumPost").where({
                _id: this.data.forumPostID
              }).watch({
                onChange:res=>{
                  this.setData({
                    forumPost:res.docs[0]
                  })


                }
              })


              ////////////////////////////////
              console.log("点赞存入good")
              // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
              console.log(res)
            }
          })
          this.setData({
            flag: true
          })
        }
        else {
          console.log("good中存在")
          //判断
          db.collection('good').where({
            userid: app.globalData.user._id,
            postid: this.data.forumPostID
          }).get({
            success: res => {
              console.log(res.data[0].isgood, "11111111111111111111")
              if (res.data[0].isgood == true) {

                db.collection('good')
                  .where({
                    userid: res.data[0].userid,
                    postid: res.data[0].postid
                  }).update({
                    data: {
                      isgood: false,
                    },
                    success: function (res) {
                      console.log("8888888888888888888888888888888888888888888888")
                      console.log(this.data.forumPostID)
                      



                      console.log("更新good")
                      // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
                      console.log(res)
                    }
                  })
                this.setData({
                  flag: false
                })
                db.collection("forumPost").where({
                  _id: this.data.forumPostID
                }).update({
                  data: {
                      goodNum:_.inc(-1)
                  },
                  success: res=> {
                  }
                })

                db.collection("forumPost").where({
                  _id: this.data.forumPostID
                }).watch({
                  onChange:res=>{
                    this.setData({
                      forumPost:res.docs[0]
                    })


                  }
                })
              }
              else {
                db.collection('good')
                  .where({
                    userid: res.data[0].userid,
                    postid: res.data[0].postid
                  }).update({
                    data: {
                      isgood: true,
                    },
                    success: function (res) {
                    console.log("成功进入")
                   
                    
                    



                      /////////////////////////////////////
                      console.log("更新good")
                      // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
                      console.log(res)
                    }
                  })
                this.setData({
                  flag: true
                })
                db.collection("forumPost").where({
                  _id: this.data.forumPostID
                }).update({
                  data: {
                      goodNum:_.inc(1)
                  },
                  success: res=> {
                  }
                })
                db.collection("forumPost").where({
                  _id: this.data.forumPostID
                }).watch({
                  onChange:res=>{
                    this.setData({
                      forumPost:res.docs[0]
                    })


                  }
                })






              }
            }
          })
        }
        console.log(res)
      }
    })
  },
  collect: function () {
    db.collection('collect').where({
      userid: app.globalData.user._id,
      postid: this.data.forumPostID
    }).get({
      success: res => {
        if (res.data[0] == null) {
          db.collection('collect').add({
            data: {
              userid: app.globalData.user._id,
              iscollect: true,
              postid: this.data.forumPost1._id,
              forumPost:this.data.forumPost1

//////////////////////////////////////
              
            },
            success: res => {
              db.collection("forumPost").where({
                _id: this.data.forumPostID
              }).update({
                data: {
                    restoreNum:_.inc(1)
                },
                success: res=> {
                }
              })

              db.collection("forumPost").where({
                _id: this.data.forumPostID
              }).watch({
                onChange:res=>{
                  this.setData({
                    forumPost:res.docs[0]
                  })


                }
              })

              // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
              console.log(res)
              console.log("添加成功")
            }
          })
          this.setData({
            flag2: true
          })
        }
        else {
          //判断

          db.collection('collect').where({
            userid: app.globalData.user._id,
            postid: this.data.forumPostID
          }).get({
            success: res => {
              if (res.data[0].iscollect == true) {
                console.log("进入if")
                db.collection('collect')
                  .where({
                    userid: res.data[0].userid,
                    postid: res.data[0].postid
                  }).update({
                    data: {
                      iscollect: false,
                    },
                    success: function (res) {


                







                      // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
                      console.log(res)
                    }
                  })
                this.setData({
                  flag2: false
                })
                db.collection("forumPost").doc(this.data.forumPostID).update({
                  data: {
                      restoreNum:_.inc(-1)
                  },
                  success: res=> {
                  }
                })
  
                db.collection("forumPost").where({
                  _id: this.data.forumPostID
                }).watch({
                  onChange:res=>{
                    this.setData({
                      forumPost:res.docs[0]
                    })
  
  
                  }
                })



              }
              else {
                console.log("进入else")
                db.collection('collect')
                  .where({
                    userid: res.data[0].userid,
                    postid: res.data[0].postid
                  }).update({
                    data: {
                      iscollect: true,
                    },
                    success: function (res) {
                      











                      // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
                      console.log(res)
                    }
                  })
                this.setData({
                  flag2: true
                })

                db.collection("forumPost").where({
                  _id: this.data.forumPostID
                }).update({
                  data: {
                      restoreNum:_.inc(1)
                  },
                  success: res=> {
                  }
                })
  
                db.collection("forumPost").where({
                  _id: this.data.forumPostID
                }).watch({
                  onChange:res=>{
                    this.setData({
                      forumPost:res.docs[0]
                    })
  
  
                  }
                })
              }
            }
          })
        }
        console.log(res)
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  // hasLook(){
  //   console.log("222222215434")
  //   db.collection('forumPost').where({
  //     _id: this.data.forumPostID
  //   }).update({
  //     data: {
  //         lookNum:_.inc(1)
  //     },
  //     success: res=> {
  //       db.collection("forumPost").doc(this.data.forumPostID)
  //       .get({
          
  //           success:res=>{
  //               console.log("查询帖子成功   ",res.data)
  //               db.collection("remark")
  //               .where({
  //                 forumPostID:this.data.forumPostID
  //               })
  //               .orderBy('postDate','asc')
  //               .get({
  //                   success:res=>{
  //                       console.log("查询评论：  ",res.data)
  //                       this.setData({
  //                           remark:res.data
  //                       })
  //                   }
  //               })
  //               this.setData({
  //                   forumPost1:res.data
  //               })
  //           }
  //       })
        
  //        console.log("howw world")
  //     }
  //   })
  // },
  // collect: function () {
  //   db.collection('collect').where({
  //     userid: app.globalData.user._id,
  //     postid: this.data.forumPostID
  //   }).get({
  //     success: res => {
  //       if (res.data[0] == null) {
  //         db.collection('collect').add({
  //           data: {
  //             userid: app.globalData.user._id,
  //             iscollect: true,
  //             postid: this.data.forumPostID,
  //             forumPost:this.data.forumPost1
  //           },
  //           success: res => {
  //             // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
  //             console.log(res)
  //             console.log("添加成功")
  //           }
  //         })
  //         this.setData({
  //           flag2: true
  //         })
  //       }
  //       else {
  //         //判断

  //         db.collection('collect').where({
  //           userid: app.globalData.user._id,
  //           postid: this.data.forumPostID
  //         }).get({
  //           success: res => {
  //             if (res.data[0].iscollect == true) {
  //               console.log("进入if")
  //               db.collection('collect')
  //                 .where({
  //                   userid: res.data[0].userid,
  //                   postid: res.data[0].postid
  //                 }).update({
  //                   data: {
  //                     iscollect: false,
  //                   },
  //                   success: function (res) {
  //                     // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
  //                     console.log(res)
  //                   }
  //                 })
  //               this.setData({
  //                 flag2: false
  //               })
  //             }
  //             else {
  //               console.log("进入else")
  //               db.collection('collect')
  //                 .where({
  //                   userid: res.data[0].userid,
  //                   postid: res.data[0].postid
  //                 }).update({
  //                   data: {
  //                     iscollect: true,
  //                   },
  //                   success: function (res) {
  //                     // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
  //                     console.log(res)
  //                   }
  //                 })
  //               this.setData({
  //                 flag2: true
  //               })
  //             }
  //           }
  //         })
  //       }
  //       console.log(res)
  //     }
  //   })
  // },






  async test1(id){
     this.setData({
        forumPostID:id
     })
  },


  async hasLook(id){
   
    await db.collection("forumPost").where({
      _id: id
    }).update({
      data: {
          lookNum:_.inc(1)
      },
      success: res=> {
        db.collection("forumPost").doc(id)
        .get({
          
            success:res=>{
                console.log("查询帖子成功   ",res.data)
                db.collection("remark")
                .where({
                  forumPostID:id
                })
                .orderBy('postDate','asc')
                .get({
                    success:res=>{
                        console.log("查询评论：  ",res.data)
                        console.log("测试good")
                        db.collection('good').where({
                          userid: app.globalData.user._id,
                          postid: this.data.forumPost1._id
                        }).watch({
                          onChange: res => {
                            console.log("21:24")
                            console.log(res.docs)
                            console.log("0000000",res.docs[0].isgood)
                            this.setData({
                              flag: res.docs[0].isgood
                            })
                          },
                          onError: err => {
                          }
                        })

                        console.log("测试collect")
                        db.collection('collect').where({
                          userid: app.globalData.user._id,
                          postid: this.data.forumPostID
                        }).watch({
                          onChange: res => {
                            console.log("521521")
                            console.log(res)
                            this.setData({
                              flag2: res.docs[0].iscollect
                            })
                          },
                          onError: err => {
                          }
                        })





                        this.setData({
                            remark:res.data
                        })
                    }
                })
                this.setData({
                    forumPost1:res.data
                })
            }
        })
      }
    })
},





  onwatch(){

     db.collection("remark")
    .where({
      forumPostID:this.data.forumPostID
    })
    .orderBy('postDate','asc')
    .watch({
      onChange:res=>{
        console.log(res)
        this.setData({
          remark:res.docs
        })
      },
      onError:err=>{

      }
    }) 
  },
   onLoad: function (options) {
    this.test1(options._id)
    this.hasLook(options._id)
    this.onwatch()
    this.setData({
      return:options.return
    })
    console.log("页面返回",options.return)
    
    console.log("传来的id为： "+this.data.forumPostID)
    
    

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    console.log("退出了")
    console.log(this.data.return)
    if(this.data.return=='post'){
      wx.redirectTo({
        url: '../post/post'
      })
    }
    else if(this.data.return=="store"){
      wx.redirectTo({
        url: '../store/store'
      })
    }
    else if(this.data.return=="reply"){
      wx.redirectTo({
        url: '../reply/reply'
      })
    }
    else if(this.data.return=="search"){
      wx.redirectTo({
        url: '../search/search'
      })
    }
    else{
      wx.switchTab({
       url: '../index/index'
      })
    }

  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    db.collection('forumPost').doc(this.data.forumPostID)
    .watch({
      onChange:res=>{
        console.log('监听用户下拉动作')
        console.log(res)
        this.setData({
          forumPost1:res.docs[0]
        })
      },
      onError:err=>{

      }
    }) 
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})