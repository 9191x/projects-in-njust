var util =require('../../utils/util.js')
const db = wx.cloud.database()
var app = getApp()
const _ = db.command;
Page({




  data: {
    forumPostID:"",
    forumPost:""
  },
  formSubmit: function (e) {  
   var a1 = e.detail.value;
   var postTime = util.formatTime(new Date());
   if(a1.content==''){
    wx.showToast({
      title: '请输入完整评论',
      icon:'error'
    })
   }
   else{
    db.collection('forumPost').where({
    _id: this.data.forumPostID
     }).update({
          data: {
              remarkNum:_.inc(1)
          },
          success: res=> {
            console.log("几次啊")
            db.collection("remark").add({
              data: {
                postTime:postTime,
                remark2num:0,
                forumPostID:this.data.forumPostID,
                forumPost:this.data.forumPost,
                anuthorID:this.data.forumPost[0].anuthorID,
                remarkerID:app.globalData.user._id,
                remarkerName:app.globalData.user.username,
                remarkerPic:app.globalData.user.userPic,
                content:a1.content
              },
              success: res => {
                console.log(res.data)
          }
        })
        console.log("评论成功")
        wx.showToast({
          title: '评论成功!',
          icon:'success'
        })
      }
    })
 
    wx.redirectTo({
      url: '../question/question?_id='+this.data.forumPostID,
      //url: '../question/question？_id='+this.data.forumPostID,
    })
  }
  },
  watchChange(){
    db.collection("remark")
   .where({
     forumPostID:this.data.forumPostID
   })
   .orderBy('postDate','asc')
   .watch({
     onChange:res=>{
       console.log('监听成功',res.docs)
       this.setData({
         remark:res.docs
       })
     },
     onError:err=>{

     }
   }) 
  },
  /**
   * 生命周期函数--监听页面加载
   */
  getData(){
    db.collection('forumPost').where({
      _id: this.data.forumPostID
    }).get({
     
      success: res=> {
         console.log("查询帖子成功   ",res.data),
         this.setData({
         forumPost:res.data  
         })
        
      }
    })

  },
  onLoad: function (options) {
    this.setData({
      forumPostID:options.forumPostID
   }) 
   console.log(123456,options.forumPostID)
   this.getData()
   this.watchChange()
   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})