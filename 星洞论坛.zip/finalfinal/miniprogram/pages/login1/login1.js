const db = wx.cloud.database()
var app = getApp()
Page({
  data: {
    openId:'',
    userInfo: {},
    hasUserInfo: false,
    canIUseGetUserProfile: false,
    user: "123",
  },
   onLoad() {
    if (wx.getUserProfile) {
      this.setData({
        canIUseGetUserProfile: true
      })
    }
     wx.cloud.callFunction({
      name: 'getOpenid',
      complete: res => {
        console.log('云函数获取到的openid: ', res.result.openid)
        getApp().globalData.openId =res.result.openid 
        this.setData({
          openId: res.result.openid,
          
        })
        db.collection('user').where({
          _openid:this.data.openId
        }).get({
          success: function (res) {
          getApp().globalData.user=res.data[0]
          console.log('又一个问题',res.data[0]._openid)
           // this.data.user=res.data
            if (res.data[0]._openid!="") {
              wx.switchTab({
                url: '../index/index',
              })              
            }
          }
    
        })




        console.log(res);
      }

      
    })
    
  },
  getUserProfile(e) {
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认
    // 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
        db.collection("user").add({
              data: {
                username: res.userInfo.nickName,
                userPic: res.userInfo.avatarUrl,
                hometown: res.userInfo.country,
              },
              success: res => {
                db.collection("user").doc(res._id)
                .get({
                  success: function (res) {
                    getApp().globalData.user=res.data
                     
                    
                    }
                })
              }
            })
        wx.switchTab({
          url: '../index/index',
        })






      }

    })
  },
  getUserInfo(e) {
    // 不推荐使用getUserInfo获取用户信息，预计自2021年4月13日起，getUserInfo将不再弹出弹窗，并直接返回匿名的用户个人信息
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
})