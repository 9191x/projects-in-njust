// pages/data/data.js
const db = wx.cloud.database()
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    openId: '',
    data: '',
    gender: '',
    gend: "",
    user: "",
    // user: {
    //   username: 'Young',
    //   birthday: '2001-10-06',
    //   job: '学生',
    //   hometown: '安徽',
    //   phone: '138-9999-9999',
    //   gender: '男',
    // },

    // portrait: '/images/user/user_1/portrait.jpg',
    pic: "",
    choose1: false,
    choose2: false,
    // gend:''

  },
  change1: function (e) {
    var c1 = this.data.choose1
    this.setData({
      choose1: !c1,
      choose2: c1
    })
  },
  change2: function (e) {
    var c2 = this.data.choose2
    this.setData({
      choose2: !c2,
      choose1: c2
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    db.collection("user")
      .where({
        _id: app.globalData.user._id
      })
      .watch({
        onChange: res => {
          console.log(res)
          this.setData({
            pic: res.docs[0].userPic,
            user: res.docs[0],
            gend: res.docs[0].gender
          })
          if (this.data.gend == "男") {
            console.log("gender", app.globalData.user.gender)
            this.setData({
              choose1: true,
              choose2: false
            })
            console.log("第二个if")
          }
          else {
            console.log("gender", app.globalData.user.gender)
            this.setData({
              choose1: false,
              choose2: true,
            })
            console.log("第二个else")
          }
          console.log("第一个")
        },
        onError: err => {

        }
      })


    this.setData({
      user: app.globalData.user,
      // portrait:app.globalData.user.portrait
    })
    console.log(this.data.choose1, this.data.choose2, "iiiiiii")
    // console.log(getApp().globalData.openId)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  formSubmit: function (e) {  //更新用户的数据
    var user_1 = e.detail.value;
    console.log(5211314)
    // console.log(getApp().globalData.openId)
    if (this.data.choose1) {
      this.setData({
        gender: '男'
      })
    }
    else if (this.data.choose2) {
      this.setData({
        gender: '女'
      })
    }
    // const _ = db.command
    console.log("联合行动的时间")
    db.collection('user').where({
      _id: getApp().globalData.user._id
    }).update({
      data: {
        username: user_1.username == "" ? this.data.username : user_1.username,
        userPic: this.data.portrait,
        gender: this.data.gender,
        phone: user_1.phone == "" ? this.data.phone : user_1.phone,
        birthday: user_1.birthday == "" ? this.data.birthday : user_1.birthday,
        job: user_1.job == "" ? this.data.job : user_1.job,
        hometown: user_1.hometown == "" ? this.data.hometown : user_1.hometown
      },
      success: res => {


        db.collection('user').where({
          _id: app.globalData.user._id
        }).get({
          success: function (res) {

            getApp().globalData.user = res.data[0]

            console.log("成功了", app.globalData.user)
            this.setData({
              user: res.data[0],
              pic: this.data.portrait
            })
          }

        })
        db.collection('remark').where({
          remarkerID: app.globalData.user._id
        }).update({
          data: {
            remarkerName: user_1.username == "" ? this.data.username : user_1.username,
            remarkerPic: this.data.portrait,
          },
          success: res => {
            console.log("我好嘞")
            console.log(res)
          }
        })



      }


    })
    console.log("更新值", app.globalData.user._id)
    db.collection('forumPost').where({
      anuthorID: app.globalData.user._id
    }).update({
      data: {
        anuthorName: user_1.username == "" ? this.data.username : user_1.username,
        anuthorPic: this.data.portrait,
      },
      success: res => {
        console.log("我好嘞")
        console.log(res)
      }
    })
    

    wx.redirectTo({
      url: '../data/data',
    })
    console.log("瑄瑄大帅比")
    wx.showToast({
      title: '修改成功',
      icon:'success'
    })
  },

  // 点击换手机相册或者电脑本地图片    
  upload: function () {
    var _this = this;
    wx.chooseImage({
      count: 1, // 默认9      
      sizeType: ['original', 'compressed'],
      // 指定是原图还是压缩图，默认两个都有      
      sourceType: ['album', 'camera'],
      // 指定来源是相册还是相机，默认两个都有    
      success: function (res) {
        // 返回选定照片的本地文件路径tempFilePath可以作为img标签的src属性显示图片  
        wx.cloud.uploadFile({
          cloudPath: Date.now() + ".jpg",
          filePath: res.tempFilePaths[0]
        }).then(res => {
          _this.setData({
            portrait: res.fileID,
            pic: res.fileID
          })
        })
      }
    })
  }

})